<?php
require_once 'pages/backend/conexion.php';

//$idGamer = $_GET["idGamer"];
  session_start();
  if (isset($_SESSION['usuario'])) {
    $usuario=$_SESSION['usuario'];
    $sql = "SELECT * FROM tGamer WHERE usuario = '".$usuario."'";

    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      while($row = mysqli_fetch_assoc($result)) {
        if($row["tipo"]=="Normal"){
          header('Location: pages/indexUsuario/index2.php');
        }else{
          header('Location: pages/indexAdmin/index.php');
        }
      }
    }
  }
  $sql = "SELECT COUNT(*) FROM tGamer";
  $result = mysqli_query($conn, $sql);
  $datos = mysqli_fetch_array($result);
  $nusuarios = $datos["COUNT(*)"];

  $sql = "SELECT SUM(monedas) FROM tGamer";
  $result = mysqli_query($conn, $sql);
  $datos = mysqli_fetch_array($result);
  $nmonedas = $datos["SUM(monedas)"];

  $sql = "SELECT COUNT(*) FROM tTorneo WHERE estatus = 'en curso' OR estatus = 'pendiente'";
  $result = mysqli_query($conn, $sql);
  $datos = mysqli_fetch_array($result);
  $ntorneos = $datos["COUNT(*)"];

  $sql = "SELECT COUNT(*) FROM tConsola";
  $result = mysqli_query($conn, $sql);
  $datos = mysqli_fetch_array($result);
  $nconsolas = $datos["COUNT(*)"];

  mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Inicio</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="icon/font/flaticon.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando header-->
    
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Inicio</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item active">Inicio</li>
              <li class="breadcrumb-item active"><a href="login.php">Sign In</a></li>
              
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
        <div class="row">
          <div class="col-md-12">
            <!-- Widget: user widget style 1 -->
            <div class="card card-widget widget-user">
              <!-- Add the bg color to the header using any of the bg-* classes -->
              <div class="widget-user-header text-white bg-info">
                <h3 class="widget-user-username text-right">GoGamer System</h3>
                <h5 class="widget-user-desc text-right"></h5>
                <br>
                <br>
                <br>
              </div>
              <div class="widget-user-image">
                <img class="img-circle" src="pages/imagenes/gogamer.png" alt="User Avatar">
                
              </div>
              <div class="card-footer">
                <div class="row">
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <span class="description-text">Torneos</span>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-4 border-right">
                    <div class="description-block">
                      <span class="description-text">Rentas</span>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <!-- /.col -->
                  <div class="col-sm-4">
                    <div class="description-block">
                      <span class="description-text">Ventas</span>
                    </div>
                    <!-- /.description-block -->
                  </div>
                  <!-- /.col -->
                </div>
                <!-- /.row -->
              </div>
            </div>
            <!-- /.widget-user -->
          </div>
          <!-- /.col -->
        </div>
        <!-- /.row -->

        <div class="row">
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-success">
              <div class="inner">
                <h3><?php echo $ntorneos; ?></h3>

                <h4>Torneos Disponibles</h4>
              </div>
              <div class="icon">
                <i class="fas fa-trophy"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-primary">
              <div class="inner">
                <h3><?php echo $nconsolas; ?></h3>

                <p>Consolas disponibles</p>
              </div>
              <div class="icon">
                <i class="fas fa-cubes"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-warning">
              <div class="inner">
                <h3><?php echo $nusuarios; ?></h3>

                <p>Usuarios Registrados</p>
              </div>
              <div class="icon">
                <i class="fas fa-user-plus"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
          <div class="col-lg-3 col-6">
            <!-- small card -->
            <div class="small-box bg-secondary">
              <div class="inner">
                <h3><?php echo $nmonedas; ?></h3>

                <p>Monedas de Usuarios</p>
              </div>
              <div class="icon">
                <i class="fas fa-coins"></i>
              </div>
            </div>
          </div>
          <!-- ./col -->
        </div>
        <!-- /.row -->
        <!--Aqui va el carricel-->
      <div class="card-body">
                <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
                  <ol class="carousel-indicators">
                    <li data-target="#carouselExampleIndicators" data-slide-to="0" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="1" class=""></li>
                    <li data-target="#carouselExampleIndicators" data-slide-to="2" class="active"></li>
                  </ol>
                  <div class="carousel-inner">
                    <div class="carousel-item">
                      <img class="d-block w-100" src="pages/imagenes/car1.jpg" alt="First slide">
                    </div>
                    <div class="carousel-item">
                      <img class="d-block w-100" src="pages/imagenes/car2.jpg" alt="Second slide">
                    </div>
                    <div class="carousel-item active">
                      <img class="d-block w-100" src="pages/imagenes/car3.jpg" alt="Third slide">
                    </div>
                  </div>
                  <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                    <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                    <span class="sr-only">Previous</span>
                  </a>
                  <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                    <span class="carousel-control-next-icon" aria-hidden="true"></span>
                    <span class="sr-only">Next</span>
                  </a>
                </div>
              </div>
              <!--Fin del carucel-->  

              <div class="row">
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Juega con nosotros</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                  En nuestro establecimiento podras encontrar una gran variedad de consolas y juegos diferentes, los cuales podras jugar por una modica cantidad, ademas, disfruta de nuestros torneos en los cuales podras ganar increibles premios!!.
              </div>
              <!-- /.card-body -->
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
          <div class="col-md-6">
            <div class="card">
              <div class="card-header">
                <h3 class="card-title">Lorem ipsum</h3>
              </div>
              <!-- /.card-header -->
              <div class="card-body">
                
                Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod
                tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam,
                quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo
                consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse
                cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non
                proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
            </div>
            <!-- /.card -->
          </div>
          <!-- /.col -->
        </div>

      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->

    <a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" aria-label="Scroll to top">
      <i class="fas fa-chevron-up"></i>
    </a>


</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="dist/js/demo.js"></script>
</body>
</html>
