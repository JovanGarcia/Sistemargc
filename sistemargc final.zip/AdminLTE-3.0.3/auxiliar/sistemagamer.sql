CREATE DATABASE sistemargc;

USE sistemargc;

#Tabla de usuarios gamers
CREATE TABLE tGamer(
    idGamer INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(45),
    paterno VARCHAR(45),
    materno VARCHAR(45),
    fechaNac DATE,
    genero VARCHAR(45),
    celular VARCHAR(45),
    correo VARCHAR(60),
    usuario VARCHAR(45),
    contrasena VARCHAR(45),
    foto VARCHAR(45),
    tipo VARCHAR(45),
    monedas INT,
    twitter VARCHAR(45),
    twitch VARCHAR(45),
    facebook VARCHAR(45),
    mixer VARCHAR(45),
    youtube VARCHAR(45),
    discord VARCHAR(45)
);

#Tabla para el historial (Sin terminar)
CREATE TABLE tHistorial(
    idHistorial INT AUTO_INCREMENT PRIMARY KEY,
    monedas INT,
    fecha DATE,
    idGamer INT,
    FOREIGN KEY (idGamer) REFERENCES tGamer (idGamer) ON DELETE CASCADE
);

#Tabla dulceria (Sin terminar)
CREATE TABLE tDulce(
    idDulce INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(45),
    costo FLOAT(10,2),
    monedas INT
);

#Tabla de accesorios
CREATE TABLE tAccesorios(
    idAccesorios INT AUTO_INCREMENT PRIMARY KEY,
    nombre VARCHAR(45),
    costo FLOAT(10,2),
    monedas INT
);

#Tabla de Consolas
CREATE TABLE tConsola(
    idConsola INT AUTO_INCREMENT PRIMARY KEY,
    plataforma VARCHAR(45),
    numero INT,
    serie VARCHAR(80),
    costo FLOAT(10,2),
    monedas INT
);

#Tabla de juegos
CREATE TABLE tJuego(
    idJuego INT AUTO_INCREMENT PRIMARY KEY,
    imagen VARCHAR(60),
    titulo VARCHAR(60),
    plataforma VARCHAR(80)
);

#Tabla intermedia muchos-muchos
CREATE TABLE tConsolaJuego(
    idConsolaJuego INT AUTO_INCREMENT PRIMARY KEY,
    idJuego INT,
    idConsola INT
);


#Tabla de registro de renta (visita)
CREATE TABLE tRenta(
    idRenta INT AUTO_INCREMENT PRIMARY KEY,
    fechaRenta DATE,
    horaRenta TIME,
    consola VARCHAR(45),
    juego VARCHAR(45),
    total FLOAT(10,2)
);


#Tabla de torneo
CREATE TABLE tTorneo(
    idTorneo INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(45),
    juego VARCHAR(45),
    fecha DATE,
    hora TIME,
    modalidad VARCHAR(45),
    forma VARCHAR(45),
    cantidad INT,
    descripcion VARCHAR(150),
    estatus VARCHAR(45),
    idPremio INT
);

#Tabla intermedia muchos-muchos
CREATE TABLE tTorneoGamer(
    idTorneoGamer INT AUTO_INCREMENT PRIMARY KEY,
    idTorneo INT,
    idGamer INT
);


#Tabla de premio
CREATE TABLE tPremio(
    idPremio INT AUTO_INCREMENT PRIMARY KEY,
    posicion INT,
    premio VARCHAR(50)
);







