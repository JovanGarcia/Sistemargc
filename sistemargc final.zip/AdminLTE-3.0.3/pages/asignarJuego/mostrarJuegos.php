<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

$sql = "SELECT a.idJuego 'id', a.imagen 'imagen', a.titulo 'titulo', a.plataforma 'plataforma', c.idConsolaJuego 'idcj' FROM tJuego a, tConsolaJuego c WHERE c.idConsola='$idConsola' AND a.idJuego=c.idJuego";
$res = $conn->query($sql);


if ($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        echo "
        <tr>
            <td>".$row["idcj"]."</td>
            <td><img  width='130' height='130' src='../imagenes/".$row["imagen"]."' alt='User Avatar'></td>
            
            <td>".$row["titulo"]."</td>
            <td>".$row["plataforma"]."</td>
            <td style='text-align: center;'>
                <a href='quitarJuego.php?idConsolaJuego=".$row["idcj"]."&idConsola=$idConsola'><button type='button' class='btn btn-danger'><i class='fas fa-times-circle'></i></button></a>
            </td>
        </tr>";
    }

} else {
    echo "0 results";
}

$conn->close();

?>