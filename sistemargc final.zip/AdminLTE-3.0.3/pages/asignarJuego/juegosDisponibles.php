<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

$sql = "SELECT j.idJuego 'idJuego', j.titulo 'titulo' FROM tJuego j, tConsola c WHERE c.idConsola='$idConsola' AND j.plataforma LIKE '%$plataforma%'";
$estado = $conn->query($sql);


if ($estado->num_rows > 0) {
    while($juego = $estado->fetch_assoc()) {
        $idJuego = $juego["idJuego"];
        echo "<option value='$idJuego'>".$juego["titulo"]."</option>";
    }
} else {
    echo "0 resultados";
}

$conn->close();




?>