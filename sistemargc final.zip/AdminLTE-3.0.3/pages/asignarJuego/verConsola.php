<?php
require_once '../backend/conexion.php';

$idConsola = $_GET["idConsola"];

$sql = "SELECT * FROM tConsola WHERE idConsola='$idConsola'";
$result = mysqli_query($conn, $sql);
$datos = mysqli_fetch_array($result);
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Detalles de la consola</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando header-->
    <?php include ('../includes/header.php'); ?>

      <?php 
      #Agregando menu
      include "../includes/menuadmin.php" ?>



    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Detalles de la consola</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item"><a href="#">Lista de Consolas</a></li>
              <li class="breadcrumb-item active">Detalles de la consola</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-lg-5 col-6">
                  <!-- small card -->
                  <div class="small-box bg-info">
                    <div class="inner">
                      <h3># <?php echo $datos["idConsola"]; ?></h3>
      
                      <p>Sistema RGC</p>
                    </div>
                    <div class="icon">
                      <i class="fas fa-shopping-cart"></i>
                    </div>
                    <a href="#" class="small-box-footer">
                      Consola disponible</i>
                    </a>
                  </div>
                </div>
                <!-- ./col -->
                <div class="col-lg-7 col-12">
                    <div class="card card-info">
                    <div class="card-header">
                      <h3 class="card-title">Información adicional</h3>
                    </div>
                    <!-- /.card-header -->
                    <div class="card-body">
                      <strong><i class="fas fa-book mr-1"></i>Plataforma</strong>
        
                      <p class="text-muted"><?php echo $datos["plataforma"]; ?></p>
        
                      <hr>
        
                      <strong><i class="fas fa-map-marker-alt mr-1"></i>No. Serie</strong>
        
                      <p class="text-muted"><?php echo $datos["serie"]; ?><p>
        
                      <hr>
        
                      <strong><i class="fas fa-pencil-alt mr-1"></i>Costo</strong>
        
                      <p class="text-muted"><?php echo $datos["costo"]." MXN"; ?></p>
        
                      <hr>
        
                      <strong><i class="far fa-file-alt mr-1"></i>Monedas (Renta)</strong>
        
                      <p class="text-muted"><?php echo $datos["monedas"]; ?></p>
                    </div>
                    <!-- /.card-body -->
                  </div>
                  <!-- /.card -->
                </div>
                <!-- /.col-->
              </div>
              <!-- /.row-->

            <div class="row mb-4 mt-4">
                <div class="col-lg-3 col-6">
                    <h4>Juegos asignados</h4>
                </div>
                <div class="col-lg-3 col-6">
                    <button type="button" class="btn btn-block bg-gradient-secondary" data-toggle="modal" data-target="#modal-info">Asignar nuevo juego</button>
                </div>
            </div>
            <!-- /.row-->

            <?php
                $idConsola = $datos["idConsola"];
                $plataforma = $datos["plataforma"];
            ?>


            <form role="form" action="asignarJuego.php" method="post">
            <div class="modal fade" id="modal-info">
                <div class="modal-dialog">
                  <div class="modal-content bg-info">
                    <div class="modal-header">
                      <h4 class="modal-title">Asignar juego a la consola</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <p>Selecciona el juego para añadirlo a la consola&hellip;</p>

                    
                        <div class="form-group">
                          <label>ID de la consola:</label>
                          <input type="text" class="form-control" id="idConsola" name="idConsola" value="<?php echo $idConsola ?>">
                        </div>
                   
                      <select class="form-control" name="listaJuegos">
                          <!--Mostrando juegos disponibles-->
                          <?php include ('juegosDisponibles.php'); ?>
                      </select>

                    </div>
                    <div class="modal-footer justify-content-between">
                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
                      <button type="submit" class="btn btn-outline-light">Guardar</button>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
              </form>


            <div class="card">
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr class="bg-info">
                      <th>ID</th>
                      <th>Imagen</th>
                      <th>Titulo</th>
                      <th>Plataforma</th>
                      <th style="text-align: center">#</th>
                    </tr>
                    </thead>
                    <tbody>
                        <?php include "mostrarJuegos.php" ?>
                    </tbody>
                    <tfoot>
                    <tr class="bg-info">
                      <th>ID</th>
                      <th>Imagen</th>
                      <th>Titulo</th>
                      <th>Plataforma</th>
                      <th style="text-align: center">#</th>
                    </tr>
                    </tfoot>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->
        </div>
    </section>
    <!-- /.content -->

    <a id="back-to-top" href="#" class="btn btn-primary back-to-top" role="button" aria-label="Scroll to top">
      <i class="fas fa-chevron-up"></i>
    </a>
  </div>
  <!-- /.content-wrapper -->

  <!--Agregando el footer-->
  <?php include ('../includes/footer.php'); ?>


</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>


<script type="text/javascript">
    $(function () {
        $("#example1").DataTable({
          "responsive": true,
          "autoWidth": false,
        });
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "responsive": true,
        });
      });
</script>

</body>
</html>
