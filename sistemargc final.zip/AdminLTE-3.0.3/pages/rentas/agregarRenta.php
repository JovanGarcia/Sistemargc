<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	

	$consola = $_POST['consola'];
	$juego = $_POST['juego'];
	$accesorio = $_POST['accesorio'];
    $idgamer = $_POST['gamer'];
    $metodo = $_POST['metodo'];

    if($metodo=="Efectivo"){
        
        $sql="SELECT * from tPlataformas where nombre = '$consola'";
        $result = $conn->query($sql);
        #echo $consola;
        while($row=$result->fetch_assoc()){
            $costoconsola=$row['costo'];
            $recompensa=$row['rmonedas'];
        }

        $sql="SELECT * from tGamer where idGamer = '$idgamer'";
        $result = $conn->query($sql);
        $nuevasmonedas=$recompensa;
        while($row=$result->fetch_assoc()){
            $nuevasmonedas+=$row['monedas'];
        }
        $juegos="";
        for ($i=0; $i < count($juego); $i++) { 
            $juegos.=$juego[$i]. " ";
        }
        $costoaccesorios=0;
        for ($i=0; $i < count($accesorio); $i++) { 
            $sql="SELECT * from tAccesorios where nombre = '$accesorio[$i]'";
            $result = $conn->query($sql);
            while($row=$result->fetch_assoc()){
            
                $costoaccesorios+=$row['costo'];
                
            }
        }

        $sql="UPDATE tGamer SET monedas = '$nuevasmonedas' WHERE idGamer = '$idgamer'";
        $result = $conn->query($sql);

        date_default_timezone_set("America/Mexico_City");
        $fecha = date("Y-m-d");
        $hora = date("h:i:s");
        $total=$costoaccesorios+$costoconsola;
        $sql = "INSERT INTO tRenta(fechaRenta, horaRenta, consola, juego, total, idGamer, metodo, monedasganadas) VALUES ('$fecha','$hora','$consola','$juegos','$total','$idgamer','$metodo', '$recompensa')";

	    if (mysqli_query($conn, $sql)) {
		    header("Location: listaRentas.php"); 
	        #echo "Consulta exitosa";
	    } else {
	        echo "Error: " . $sql . "" . mysqli_error($conn);
	    }
	    $conn->close();
    }else{
        $sql="SELECT * from tPlataformas where nombre = '$consola'";
        $result = $conn->query($sql);
        #echo $consola;
        while($row=$result->fetch_assoc()){
            $costoconsola=$row['cmonedas'];
        }

        $sql="SELECT * from tGamer where idGamer = '$idgamer'";
        $result = $conn->query($sql);
        $nuevasmonedas=0;
        while($row=$result->fetch_assoc()){
            $nuevasmonedas=$row['monedas']-$costoconsola;
        }
        $juegos="";
        for ($i=0; $i < count($juego); $i++) { 
            $juegos.=$juego[$i]. " ";
        }
        $costoaccesorios=0;
        for ($i=0; $i < count($accesorio); $i++) { 
            $sql="SELECT * from tAccesorios where nombre = '$accesorio[$i]'";
            $result = $conn->query($sql);
            while($row=$result->fetch_assoc()){
            
                $costoaccesorios+=$row['monedas'];
                
            }
        }

        $nuevasmonedas=$nuevasmonedas-$costoaccesorios;
        $recompensa=0;
        if($nuevasmonedas<0){
            header("Location: FormRentas.php?mensaje=1");
        }else{
            $sql="UPDATE tGamer SET monedas = '$nuevasmonedas' WHERE idGamer = '$idgamer'";
            $result = $conn->query($sql);

            date_default_timezone_set("America/Mexico_City");
            $fecha = date("Y-m-d");
            $hora = date("h:i:s");
            $total=$costoaccesorios+$costoconsola;
            $sql = "INSERT INTO tRenta(fechaRenta, horaRenta, consola, juego, total, idGamer, metodo, monedasganadas) VALUES ('$fecha','$hora','$consola','$juegos','$total','$idgamer','$metodo', '$recompensa')";

	        if (mysqli_query($conn, $sql)) {
		        header("Location: listaRentas.php"); 
	            #echo "Consulta exitosa";
	        } else {
	            echo "Error: " . $sql . "" . mysqli_error($conn);
	        }
	        $conn->close();
        }
    }
	


?>