<?php 
  #Conectando a la base de datos
  include ('../backend/conexion.php');
  if(isset($_GET['mensaje'])){
    $mensaje="El usuario no cuenta con monedas suficientes";
  }else{
    $mensaje="";
  }
 ?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer  | Registro de renta</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!--Flaticon-->
    <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css"> 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando el header-->
    <?php include ('../includes/header.php'); ?>


      <!--Agregando menu -->
      <?php include ('../includes/menuAdmin.php') ?>


    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Registro de renta</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">General Form</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Renta</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="agregarRenta.php" method="post"  enctype="multipart/form-data">
                <div class="card-body">

                  <!--Plataforma a elegir-->
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                          
                        <label>Consola*</label>
                        <select for="consola" name="consola" class="selectpicker">
                        <?php
                            $sql="SELECT * from tConsola";
                            $result = $conn->query($sql);
                            while($row=$result->fetch_assoc()){
                          ?>
                          <option value="<?php echo $row['plataforma'] ?>"><?php echo $row['plataforma'], " (",$row['numero'],")" ?></option>
                          <?php } ?>
                        </select>
                            
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <h3></h3>
                  </div>

                  <!--Numero de consola-->
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                      <label>Juego </label>
                        <select for="juego" name="juego[]" class="selectpicker" multiple>
                        <?php
                            $sql="SELECT * from tJuego";
                            $result = $conn->query($sql);
                            while($row=$result->fetch_assoc()){
                          ?>
                          <option value="<?php echo $row['titulo'] ?>"><?php echo $row['titulo'] ?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>

                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Accesorios</label>
                        <select for="accesorio" name="accesorio[]" class="selectpicker" multiple>
                        <?php
                            $sql="SELECT * from tAccesorios";
                            $result = $conn->query($sql);
                            while($row=$result->fetch_assoc()){
                          ?>
                          <option value="<?php echo $row['nombre'] ?>"><?php echo $row['nombre'] ?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div><h3>Pago</h3></div>

                <div class="row">
                  <!--Costo de la consola-->
                  <div class="col-sm-4">
                      <!-- number input -->
                      <div class="form-group">
                        <label>Gamer*</label>
                        <select for="gamer" name="gamer" class="selectpicker" data-live-search="true">
                        <?php
                            $sql="SELECT * from tGamer";
                            $result = $conn->query($sql);
                            while($row=$result->fetch_assoc()){
                          ?>
                          <option value="<?php echo $row['idGamer'] ?>"><?php echo $row['nombre']. "  ".$row['paterno']. " ".$row['materno'] ?></option>
                          <?php } ?>
                        </select>
                      </div>
                    </div>
                    

                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Metodo de pago</label>
                        <select for="metodo" name="metodo" class="selectpicker">
                          <option value="Efectivo">Efectivo</option>
                          <option value="Monedas">Monedas</option>
                        </select>
                      </div>
                    </div>

                </div>
                <!-- /.card-body -->
                <div>
                  <h3><?php echo $mensaje ?></h3>
                </div>

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Registrar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.3
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/i18n/defaults-*.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

  })
</script>
</body>
</html>
