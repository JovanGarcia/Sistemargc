<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$sql="SELECT * from tRenta";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row=$result->fetch_assoc()){
            $iduser=$row['idGamer'];
            $sql2="SELECT * FROM tGamer WHERE idGamer=$iduser";
            $result2=$conn->query($sql2);
            while($row2=$result2->fetch_assoc()){

            
		echo "
		<tr>
            <td>".$row['idRenta']."</td>
            <td>".$row2['nombre']. "  ".$row2['paterno']. " ".$row2['materno']."</td>
			<td>".$row['fechaRenta']."</td>
			<td>".$row['horaRenta']."</td>
			<td>".$row['consola']."</td>
            <td>".$row['juego']."</td>
            <td>".$row['total']."</td>
            <td>".$row['metodo']."</td>
            <td>".$row['monedasganadas']."</td>
			
			<td style='text-align: center;'>
                <div class='btn-group'>                    
                    
                </div>
            </td>
		</tr>
        ";
    }
		}
	} else {
	    echo "0 results";
	}

	$conn->close();
?>