<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

session_start();
  if (isset($_SESSION['usuario'])) {
    $usuario=$_SESSION['usuario'];
    $sql = "SELECT * FROM tGamer WHERE usuario = '".$usuario."'";
    $result = mysqli_query($conn, $sql);
    $datos = mysqli_fetch_array($result);

	$idgamer = $datos["idGamer"];
  }

#Obteniendo los datos del dulce
$iddulce = $_GET['id'];

$sql = "SELECT monedas FROM tDulce";
$result = mysqli_query($conn, $sql);
$datos = mysqli_fetch_array($result);

$monedas = $datos["monedas"];

$fecha = date("Y"). "-" .date("m") . "-" . date("d");

$sql = "INSERT INTO tHistorial(monedas, fecha, idGamer) VALUES ('$monedas','$fecha','$idgamer')";
if (mysqli_query($conn, $sql)) {
    #echo "Sentencia exitosa";
} else {
	echo "Error: " . $sql . "" . mysqli_error($conn);
}

$conn->close();

header('Location: ViewcomprarDulceria.php');

?>