<?php
$select="SELECT * from tPremio WHERE idTorneo='$idTorneo' AND asignar='0'";
$resPremio = $conn->query($select);

    if ($resPremio->num_rows > 0) {
        while($premio=$resPremio->fetch_assoc()){
            echo "<option value='".$premio["idPremio"]."'>".$premio["idPremio"]." : Lugar No. ".$premio["posicion"]." : ".$premio["premio"]."</option>";
        }
    }else{
        echo "<option>No hay premios disponibles...</option>";
    }
?>
