<?php
	include ('../backend/conexion.php');

    $idPremio = $_GET['idPremio'];
    $idTorneo = $_GET['idTorneo'];

	$sql="DELETE FROM tPremio WHERE idPremio='$idPremio'";

	if (mysqli_query($conn, $sql)) {
        echo "<script type='text/javascript'>
        window.location.href='FormAgregarTorneo.php?idTorneo=$idTorneo';
        </script>";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	    $conn->close();


?>