<?php
  include_once "../backend/conexion.php";
  include ('claseTorneos.php');


  #Obteniendo el id del torneo
  $idTorneo = $_GET["idTorneo"];

  $selectTorneo = "SELECT * FROM tTorneo WHERE idTorneo=".$idTorneo;
  $resTorneo = mysqli_query($conn, $selectTorneo);
  $torneo = mysqli_fetch_array($resTorneo);

  $titulo = $torneo["titulo"];
  $descripcion = $torneo["descripcion"];
  $juego2 = $torneo["juego"];
  $fecha = $torneo["fecha"];
  $hora = $torneo["hora"];
  $forma = $torneo["forma"];
  $limite = $torneo["limite"];
  $estatus = $torneo["estatus"];
  $idModalidad = $torneo["idModalidad"];
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer| Agregar Torneo</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!--Flaticon-->
    <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css"> 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando header-->
    <?php include ('../includes/header.php'); ?>
      
      <?php 
      #Agregando menu
      include "../includes/menuadmin.php" ?>

    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Agregar Torneo</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item"><a href="#">Lista de Torneos</a></li>
              <li class="breadcrumb-item active">Agregar Torneo</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Formulario para la creación del torneo</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="editarTorneo.php?idTorneo=<?php echo $idTorneo ?>" method="post"  enctype="multipart/form-data">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-7">
                      <!--Titulo-->
                      <div class="form-group">
                        <label>Título del torneo*</label>
                        <input type="text" class="form-control" placeholder="Ingresa un título para el torneo..." id="titulo" name="titulo" value="<?php echo $titulo ?>" required>
                      </div>
                    </div>
                    <div class="col-sm-5">
                      <!--Titulo-->
                      <div class="form-group">
                        <label>Estatus*</label>
                        <select class="form-control" id="estatus" name="estatus">
                          <!--Función para mostrar las opciones de estatus-->
                          <?php opcEstatus($estatus); ?>
                        </select>
                      </div>
                    </div>
                </div>
                <!-- /. row-->
                <div class="row">
                    <div class="col-sm-8">
                        <div class="form-group">
                          <label>Descripción*</label>
                          <textarea class="form-control" rows="4" placeholder="Ingresa una descripción ..." id="descripcion" name="descripcion" required><?php echo $descripcion ?></textarea>
                        </div>
                      </div>
                </div>
                <!-- .row -->
                <hr>
                <div class="row">
                    <div class="col-sm-4">
                        <div class="form-group">
                        <label>Forma*</label>
                        <select class="form-control" id="forma" name="forma" required>
                            <!--Función para mostrar las opciones de la forma-->
                            <?php opcForma($forma); ?>
                        </select>
                        </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group">
                    <label>Fecha del torneo*</label>
                    <input type="date" class="form-control" id="fecha" name="fecha" required value="<?php echo $fecha ?>">
                    </div>
                  </div>
                  <div class="col-sm-4">
                    <div class="form-group">
                    <label>Hora*</label>
                    <input type="time" class="form-control" id="hora" name="hora" required value="<?php echo $hora ?>">
                    </div>
                  </div>
                </div>
                <!-- /.row-->
                
            <div class="row">
                <div class="col-sm-5">
                    <div class="form-group">
                    <label>Seleccionar juego*</label>
                    <select class="form-control" name="juego" required>
                         <!--Funcion para mostrar las opciones de juego-->
                        <?php  opcJuego($conn,$juego,$juego2); ?>
                    </select>
                    </div>
              </div>

              <div class="col-sm-4">
                <div class="form-group">
                <label>Modalidad*</label>
                <select class="form-control" name="idModalidad" required>
                  
                  <?php

                       //Realizando consulta para las modalidades
                       $selectModalidad2="SELECT * from tModalidad WHERE idModalidad='$idModalidad'";
                       $modr2 = $conn->query($selectModalidad2);
 
                       if($modr2->num_rows>0){
                         while($modalidad2=$modr2->fetch_assoc()){    
                           echo "<option value='".$modalidad2["idModalidad"]."'>".$modalidad2["tipo"]."</option>";
                         }
                       } else {
                         echo "<option value='0'>No hay modalidades</option>";
                       }

                      //Realizando consulta para las modalidades
                      $selectModalidad="SELECT * from tModalidad";
                      $modr = $conn->query($selectModalidad);

                      if($modr->num_rows>0){
                        while($modalidad=$modr->fetch_assoc()){    
                          echo "<option value='".$modalidad["idModalidad"]."'>".$modalidad["tipo"]."</option>";
                        }
                      } else {
                        echo "<option value='0'>No hay modalidades</option>";
                      }
                  ?>
                </select>
                </div>
              </div>
              <div class="col-sm-3">
                <div class="form-group">
                <label>Cantidad de equipos*</label>
                <?php

                    //Realizando consulta para las modalidades
                    $sql4="SELECT * from tModalidad WHERE idModalidad='$idModalidad'";
                    $cnt = $conn->query($sql4);

                    if($cnt->num_rows>0){
                      while($cmax=$cnt->fetch_assoc()){
                        $mgrupo = $cmax["grupo"];
                        $totalmax = $limite/$mgrupo;
                        
                        echo "<input type='number' class='form-control' id='limite' name='limite' min=1 max=20 value='$totalmax' required>";
                      }
                    } else {
                      echo "Error en cantidad de equipos";
                    }
                   
                   // <input type="number" class="form-control" id="limite" name="limite" min=1 max=20 required>
                ?>
               
                </div>
              </div>
            </div>
            <button type="submit" class="btn btn-primary" name="registrar" id="registrar">Guardar</button>
          <hr>
          </form>

             <!--Formulario para agregar premios-->
             <?php include ('FormPremios.php'); ?>

          <hr>
         

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                    <!--Mostrar la lista de premios-->
                    <?php include ('mostrarPremios.php'); ?>
                </div>
                <!--/.footer-->

            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

    <!--Agregando el footer-->
    <?php include ('../includes/footer.php'); ?>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

  })
</script>
</body>
</html>
