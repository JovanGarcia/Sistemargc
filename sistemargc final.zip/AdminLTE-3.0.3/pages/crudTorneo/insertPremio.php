<?php
    include_once "../backend/conexion.php";

    $idTorneo = $_GET['idTorneo'];
    $posicion = $_POST['posicion'];
    $premio = $_POST['premio'];
    $asignar = 0;

    echo "idTorneo ".$idTorneo;
    echo "  posicion ".$posicion;
    echo "  premio ".$premio;
    echo "  asignar ".$asignar;

    $sql = "INSERT INTO tPremio(posicion, premio, asignar, idTorneo)
    VALUES ('$posicion','$premio','$asignar','$idTorneo')";

    if (mysqli_query($conn, $sql)) {
        echo "<script type='text/javascript'>
        window.location.href='FormEditarTorneo.php?idTorneo=$idTorneo';
        </script>";
    } else {
    echo "Error: " . $sql . "" . mysqli_error($conn);
    }
        $conn->close();
?>