<?php
	#Conectando a la base de datos
	include ('../backend/conexion.php');

    
$sql="SELECT idEquipo, nombreEquipo, idTorneo, idPremio FROM tEquipo e WHERE e.idTorneo='$idTorneo'";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($part=$result->fetch_assoc()){
            echo "
            <tr style='text-align:center; '>
                <td>".$part["idEquipo"]."</td>
                <td>".$part["nombreEquipo"]."</td>
                <td>".$part["idTorneo"]."</td>
                <td>";
                $suPremio = $part["idPremio"];
                if (is_null($suPremio)){
                    echo "Sin premio asignado";
                }else{
                    echo "<div class='btn-group'>              
                    <a href='quitarPremio.php?idEquipo=".$part['idEquipo']."&idPremio=".$part['idPremio']."&idTorneo=".$idTorneo."'><button type='button' class='btn btn-danger'><i class='fas fa-times mr-2'></i>Quitar premio</button></a>
                     </div>";
                }		
               "</td>
            </tr>";
            
        }
    } else {
        echo "0 Resultados";
    }

$conn->close();

?>