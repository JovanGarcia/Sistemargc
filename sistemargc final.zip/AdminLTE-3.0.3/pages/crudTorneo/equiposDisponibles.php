<?php
$sql3="SELECT * FROM tEquipo WHERE idTorneo='$idTorneo' AND idPremio IS NULL";
$resEquipo = $conn->query($sql3);

    if ($resEquipo->num_rows > 0) {
        while($equipo=$resEquipo->fetch_assoc()){
            echo "<option value='".$equipo["idEquipo"]."'>Equipo No. ".$equipo["idEquipo"]." : ".$equipo["nombreEquipo"]."</option>";
        }
    }else{
        echo "<option>No hay equipos disponibles...</option>";
    }
?>
