<?php

#Estableciendo conexión
require_once '../backend/conexion.php';
#Clase que contiene funciones necesarias en la seccion de Torneos
include ('claseTorneos.php');

#Obteniendo los datos para la tabla tTorneo
$idTorneo = $_GET['idTorneo'];
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];
$juego = $_POST['juego'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$forma = $_POST['forma'];
$limite = $_POST['limite'];
$estatus = $_POST['estatus'];
$idModalidad = $_POST['idModalidad'];

#Calculando la 
$total = limiteParticipantes($conn, $limite, $idModalidad);

echo "idTorneo= ".$idTorneo."<br>";
echo "titulo= ".$titulo."<br>";
echo "descripcion= ".$descripcion."<br>";
echo "fecha= ".$fecha."<br>";
echo "hora= ".$hora."<br>";
echo "forma= ".$forma."<br>";
echo "limite= ".$limite."<br>";
echo "estatus= ".$estatus."<br>";
echo "idModalidad= ".$idModalidad."<br>";
echo "total= ".$total."<br>";

#Consulta para modificar campos de la tabla tTorneo
$sql = "UPDATE tTorneo SET titulo='$titulo', descripcion = '$descripcion', juego = '$juego', fecha = '$fecha', hora = '$hora', forma = '$forma', limite = '$total', estatus = '$estatus', idModalidad = '$idModalidad'
        WHERE idTorneo='$idTorneo'";


if (mysqli_query($conn, $sql)) {
      //echo "Actualización completada";
      echo "<script type='text/javascript'>
      window.location.href='listaTorneos.php';
      </script>";
   } else {
      echo "Ha ocurrido un error al actualizar los datos. " . mysqli_error($conn);
   }
   mysqli_close($conn);


?>