<?php
#Estableciendo conexión
require_once '../backend/conexion.php';

//Archivo para asignar el premio a uno de los equipos que participan en un Torneo.
$idTorneo = $_GET["idTorneo"];
$idPremio = $_GET["idPremio"];
$idEquipo = $_GET["idEquipo"];

echo "idTorneo = ".$idTorneo."<br>";
echo "idPremio = ".$idPremio."<br>";
echo "idEquipo = ".$idEquipo."<br>";

$nulo = null;

#Quitamos el idPremio a la tabla tEquipo dejandolo como NULL
$sql = "UPDATE tEquipo SET idPremio=NULL
        WHERE idEquipo='$idEquipo'";

#Indicamos a la tabla tPremio que el premio a sido quitado a un equipo 
$sql2 = "UPDATE tPremio SET asignar='0'
        WHERE idPremio='$idPremio'";


if (mysqli_query($conn, $sql)) {
    if (mysqli_query($conn, $sql2)) {
            echo "<script type='text/javascript'>
            window.location.href='verTorneo.php?idTorneo=".$idTorneo."';
            </script>";
        }else{
            echo "Ha ocurrido un error en actualizar tPremio " . mysqli_error($conn);
        }
   } else {
      echo "Ha ocurrido un error en actualizar tEquipo " . mysqli_error($conn);
   }
//Finalizando conexión   
mysqli_close($conn);


?>