<?php
	#Conectando a la base de datos
	include ('../backend/conexion.php');

    $idTorneo = $_GET['idTorneo'];
    
	$sql="DELETE FROM tTorneo WHERE idTorneo='$idTorneo'";

	$sql1="DELETE FROM tEquipo WHERE idTorneo='$idTorneo'";

	$sql2="DELETE FROM tPremio WHERE idTorneo='$idTorneo'";

	if (mysqli_query($conn, $sql)) {
        #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}

	if (mysqli_query($conn, $sql1)) {
        #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql1 . "" . mysqli_error($conn);
	}

	if (mysqli_query($conn, $sql2)) {
        #echo "Consulta exitosa";
        echo "<script type='text/javascript'>
        window.location.href='listaTorneos.php';
        </script>";
	} else {
	    echo "Error: " . $sql2 . "" . mysqli_error($conn);
	}
	    $conn->close();
?>