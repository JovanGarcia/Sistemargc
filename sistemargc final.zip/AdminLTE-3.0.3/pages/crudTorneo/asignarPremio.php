    <!--Modal para invitar usuario-->
    <form role="form" action="asignarPremioEquipo.php?idTorneo=<?php echo $idTorneo ?>" method="post">
            <div class="modal fade" id="modal-asignarPremio">
                <div class="modal-dialog">
                  <div class="modal-content bg-info">
                    <div class="modal-header">
                      <h4 class="modal-title">Asignar Premio</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <p>Seleccione uno de los premios y equipos disponibles</p>
                        <!--Nombre del equipo-->
                        <div class="row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <label>Equipos disponibles*</label>
                                    <select class="form-control" name="idEquipo" id="idEquipo" required>
                                        <!--Mostrar los participantes disponibles-->
                                        <?php include ('equiposDisponibles.php'); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                           <!--Premios disponibles-->
                           <div class="row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <label>Premios disponibles*</label>
                                    <select class="form-control" name="idPremio" id="idPremio" required>
                                        <!--Mostrar los participantes disponibles-->
                                        <?php include ('premiosDisponibles.php'); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6" style="text-align: justify;">
                                <h6 class="text-lime">AVISO: Usted está apúnto de asignar un premio disponible del Torneo No. <?php echo $datos["idTorneo"] ?></h6>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer justify-content-between">
                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
                        <!--Validando el botón para asignar premios-->
                        <?php 
                                //Verificando si aun existen equipos y premios sin asignar
                                $existePremios = existePremios($conn, $idTorneo);
                                $existeEquipos = existeEquipos($conn, $idTorneo);

                                if($existePremios <= 0 OR $existeEquipos <=0)
                                {
                                    echo "<button type='submit' class='btn btn-outline-light' disabled>Asignar</button>";
                                }
                                else{
                                    echo "<button type='submit' class='btn btn-outline-light'>Asignar</button>";
                                }
                            ?>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
    </form>
    <!--/.form-->

<!--Boton para asignar premios-->
<?php 
    if($datos["estatus"] != "Finalizado")
        {
            echo "<button type='button' class='btn btn-info' data-toggle='modal' data-target='#modal-asignarPremio' disabled><i class='fas fa-file-signature mr-1'></i>Asignar premio</button>";
        }
        else
        {
            echo "<button type='button' class='btn btn-info' data-toggle='modal' data-target='#modal-asignarPremio'><i class='fas fa-file-signature mr-1'></i>Asignar premio</button>";
        }
?>