<?php
require_once '../backend/conexion.php';
//Clase de los torneos
include ('claseTorneos.php');
?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Lista de torneos</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando header-->
    <?php include ('../includes/header.php'); ?>

      <?php 
      #Agregando menu
      include "../includes/menuadmin.php" ?>



    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Lista de Torneos</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item active">Lista de Torneos</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">

            <!--Titulo y boton de la tabla-->
            <div class="row mb-4 mt-4">
                <div class="col-lg-4 col-8">
                    <h4>Lista de Torneos registrados en el sistema GoGamer</h4>
                </div>
                <div class="col-lg-2 col-4">
                    <button type="button" class="btn btn-block bg-gradient-secondary" data-toggle="modal" data-target="#modal-info">Agregar Torneo</button>
                </div>
            </div>
            <!-- /.row-->

            <!--Inicio del modal-->
            <div class="modal fade" id="modal-info">
                <div class="modal-dialog">
                  <div class="modal-content bg-info">
                    <div class="modal-header">
                      <h4 class="modal-title">Agregar nuevo Torneo</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <p>¿Estás seguro de que deseas iniciar con la creación de un nuevo Torneo?</p>

                    </div>
                    <div class="modal-footer justify-content-between">
                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cancelar</button>
                      <a href="FormAgregarTorneo.php"><button type="button" class="btn btn-outline-light">Aceptar</button></a>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
              

            <div class="card">
                <div class="card-body">
                  <table id="example1" class="table table-bordered table-striped">
                    <thead>
                    <tr style="text-align: center" >
                      <th>ID</th>
                      <th>Titulo</th>
                      <th>Juego</th>
                      <th>Fecha y Hora</th>
                      <th>Forma</th>
                      <th>Límite</th>
                      <th>Estatus</th>  
                      <th></th> 
                    </tr>
                    </thead>
                    <tbody>
                        <?php include "mostrarTorneos.php" ?>
                    </tbody>
                    <tfoot>
                    <tr  style="text-align: center">
                      <th>ID</th>
                      <th>Titulo</th>
                      <th>Juego</th>
                      <th>Fecha y Hora</th>
                      <th>Forma</th>
                      <th>Límite</th>
                      <th>Estatus</th>  
                      <th></th> 
                    </tr>
                    </tfoot>
                  </table>
                </div>
                <!-- /.card-body -->
              </div>
              <!-- /.card -->

              
        </div>
    </section>
    <!-- /.content -->

    <a id="back-to-top" href="#" class="btn btn-warning back-to-top" role="button" aria-label="Scroll to top">
      <i class="fas fa-chevron-up"></i>
    </a>
  </div>
  <!-- /.content-wrapper -->

  <!--Agregando el footer-->
  <?php include ('../includes/footer.php'); ?>


</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>


<script type="text/javascript">
    $(function () {
        $("#example1").DataTable({
          "responsive": true,
          "autoWidth": false,
        });
        $('#example2').DataTable({
          "paging": true,
          "lengthChange": false,
          "searching": false,
          "ordering": true,
          "info": true,
          "autoWidth": false,
          "responsive": true,
        });
      });
</script>

</body>
</html>
