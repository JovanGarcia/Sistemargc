<?php
$conteo=posicionLugar($conn, $idTorneo);
//echo "conteo: ".$conteo;
?>

<form role="form" action="insertPremio.php?idTorneo=<?php echo $idTorneo ?>" method="post" >
    <div class="row">
        <div class="col-sm-1">
            <div class="form-group">
                <label>Posición</label>
                <input style="background-color: rgb(59, 59, 59); color: white;"  type="number" class="form-control" id="posicion" name="posicion" 
                value="<?php echo $conteo ?>">
            </div>
        </div>
        <div class="col-sm-6">
            <div class="form-group">
                <label>Descripción del premio</label>
                <input type="text" class="form-control" placeholder="Descripción del premio..." id="premio" name="premio">
            </div>
        </div>
        <div class="col-sm-3">
        <div class="form-group">
                <label class="text-white">Añadir</label>
                <button type="sumbit" class="btn btn-block bg-gradient-secondary" name="registrar" id="registrar">Añadir</button>
            </div>
        </div>
    </div>
</form>