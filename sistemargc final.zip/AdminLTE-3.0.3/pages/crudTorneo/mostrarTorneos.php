<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$sql="SELECT * from tTorneo";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($torneo=$result->fetch_assoc()){
		echo "
		<tr>
			<td>".$torneo['idTorneo']."</td>
            <td>".$torneo['titulo']."</td>
            <td>".$torneo['juego']."</td>
			<td>".$torneo['fecha']." , ".$torneo['hora']."</td>
			<td>".$torneo['forma']."</td>
			<td>".$torneo['limite']."</td>";
				verEstatus($torneo);
		echo "<td style='text-align: center;'>
				<div class='btn-group'>   
					<a href='verTorneo.php?idTorneo=".$torneo["idTorneo"]."'><button type='button' class='btn btn-success'><i class='fas fa-eye'></i></button></a>                 
                    <a href='FormEditarTorneo.php?idTorneo=".$torneo['idTorneo']."'><button type='button' class='btn btn-primary'><i class='fas fa-cog'></i></button></a>
                    <a href='deleteTorneo.php?idTorneo=".$torneo['idTorneo']."'> <button type='button' class='btn btn-danger'><i class='fas fa-trash-alt'></i></button></a>
                </div>
            </td>
		</tr>
		";
		}
	} else {
	    echo "0 Resultados";
	}

	$conn->close();
?>