<?php

#Estableciendo conexión
require_once '../backend/conexion.php';
#Clase que contiene funciones necesarias en la seccion de Torneos
include ('claseTorneos.php');

#Obteniendo los datos para la tabla tTorneo
$titulo = $_POST['titulo'];
$descripcion = $_POST['descripcion'];
$juego = $_POST['juego'];
$fecha = $_POST['fecha'];
$hora = $_POST['hora'];
$forma = $_POST['forma'];
$limite = $_POST['limite'];
$estatus = $_POST['estatus'];
$idModalidad = $_POST['idModalidad'];

#Calculando la 
$total = limiteParticipantes($conn, $limite, $idModalidad);

echo "idTorneo= ".$idTorneo."<br>";
echo "titulo= ".$titulo."<br>";
echo "descripcion= ".$descripcion."<br>";
echo "fecha= ".$fecha."<br>";
echo "hora= ".$hora."<br>";
echo "forma= ".$forma."<br>";
echo "limite= ".$limite."<br>";
echo "estatus= ".$estatus."<br>";
echo "idModalidad= ".$idModalidad."<br>";
echo "total= ".$total."<br>";

//Consulta para registrar torneo en tTorneo
$sql = "INSERT INTO tTorneo(titulo, descripcion, juego, fecha, hora, forma, limite, estatus, idModalidad)
VALUES ('$titulo','$descripcion','$juego','$fecha','$hora','$forma','$total','$estatus','$idModalidad')";

if (mysqli_query($conn, $sql)) {
    echo "<script type='text/javascript'>
    window.location.href='listaTorneos.php';
    </script>";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
    $conn->close();


?>