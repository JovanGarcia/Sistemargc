<?php

 //Función para retornar la posición actual del premio
function posicionLugar($conn, $idTorneo){
    
     $sql="SELECT COUNT(*) 'numero' from tPremio WHERE idTorneo = '$idTorneo'";
     $result = $conn->query($sql);

     if($result->num_rows>0){
       while($dato=$result->fetch_assoc()){    
         $numero = $dato["numero"];
         return ($numero+1);
         //echo "es ".($numero+1);
       }
     } else {
         return 1;
         //echo "es 1";
     }
}

function limiteParticipantes($conn, $limite, $idModalidad){
  $sql="SELECT * from tModalidad WHERE idModalidad = '$idModalidad'";
  $result = $conn->query($sql);

     if($result->num_rows>0){
       while($dato=$result->fetch_assoc()){
         $grupo = $dato["grupo"];
         $total=$limite*$grupo;    
         return $total;
       }
     } else {
        echo "Ha ocurrido un error";
        return 0;
     }
}

function obtenerModalidad($conn, $idModalidad){
  $sql="SELECT * from tModalidad WHERE idModalidad = '$idModalidad'";
  $result = $conn->query($sql);

     if($result->num_rows>0){
       while($dato=$result->fetch_assoc()){
         $modalidad=$dato["tipo"];
         return $modalidad;
       }
     } else {
        echo "Ha ocurrido un error en la modalidad";
        return 0;
     }
}

function opcEstatus($estatus){
    if($estatus == "Pendiente")
    {
      echo "<option value='Pendiente'>Pendiente</option>";
      echo "<option value='En curso'>En curso</option>";
      echo "<option value='Finalizado'>Finalizado</option>";
      echo "<option value='Cancelado'>Cancelado</option>";
    }

    if($estatus == "En curso")
    {
      echo "<option value='En curso'>En curso</option>";
      echo "<option value='Pendiente'>Pendiente</option>";
      echo "<option value='Finalizado'>Finalizado</option>";
      echo "<option value='Cancelado'>Cancelado</option>";
    }

    if($estatus == "Finalizado")
    {
      echo "<option value='Finalizado'>Finalizado</option>";
      echo "<option value='Pendiente'>Pendiente</option>";
      echo "<option value='En curso'>En curso</option>";
      echo "<option value='Cancelado'>Cancelado</option>";
    }

    if($estatus == "Cancelado")
    {
      echo "<option value='Cancelado'>Cancelado</option>";
      echo "<option value='Pendiente'>Pendiente</option>";
      echo "<option value='En curso'>En curso</option>";
      echo "<option value='Finalizado'>Finalizado</option>";
    }
}

function verEstatus($torneo){
    if($torneo['estatus'] == "Pendiente")
    {
      echo "<td class='text-primary'>".$torneo['estatus']."</td>";
    }
    if($torneo['estatus'] == "En curso")
    {
      echo "<td class='text-success'>".$torneo['estatus']."</td>";
    }
    if($torneo['estatus'] == "Finalizado")
    {
      echo "<td class='text-danger'>".$torneo['estatus']."</td>";
    }
    if($torneo['estatus'] == "Cancelado")
    {
      echo "<td class='text-secondary'>".$torneo['estatus']."</td>";
    }

}


function opcForma($forma){
    if($forma == "Presencial")
    {
      echo "<option value='Presencial'>Presencial</option>";
      echo "<option value='En línea'>En línea</option>";
      echo "<option value='Presencial/En línea'>Ambos</option>";
    }
    if($forma == "En línea")
    {
      echo "<option value='En línea'>En línea</option>";
      echo "<option value='Presencial'>Presencial</option>";
      echo "<option value='Presencial/En línea'>Ambos</option>";
    }
    if($forma == "Presencial/En línea")
    {
      echo "<option value='Presencial/En línea'>Ambos</option>";
      echo "<option value='Presencial'>Presencial</option>";
      echo "<option value='En línea'>En línea</option>";
    }
}

function opcJuego($conn, $juego, $juego2){
    //Realizando consulta para los juegos
    $selectJuego="SELECT * from tJuego";
    $mj = $conn->query($selectJuego);

    echo "<option value='".$juego2."'>".$juego2."</option>";

    if($mj->num_rows>0){
      while($juego=$mj->fetch_assoc()){   
        if($juego["titulo"]!=$juego2)
        {
          echo "<option value='".$juego["titulo"]."'>".$juego["titulo"]."</option>";
        }

      }
    } else {
      echo "<option value='0'>No hay juegos</option>";
    }
}


//FUNCIONES PARA VALIDAR LA ASIGNACION DE PREMIOS A EQUIPOS

function existePremios($conn, $idTorneo){
$sql="SELECT COUNT(*) 'conteo' from tPremio WHERE idTorneo='$idTorneo' AND asignar='0'";
$resPremio = $conn->query($sql);

    if ($resPremio->num_rows > 0) {
        while($premio=$resPremio->fetch_assoc()){
            $conteo = $premio["conteo"];
            return $conteo;
        }
    }else{
      return 0;
        //echo "No hay premios disponibles...";
    }
  
}

function existeEquipos($conn, $idTorneo){
  $sql="SELECT COUNT(*) 'conteo' FROM tEquipo WHERE idTorneo='$idTorneo' AND idPremio IS NULL";
  $resEquipo = $conn->query($sql);
  
      if ($resEquipo->num_rows > 0) {
          while($equipo=$resEquipo->fetch_assoc()){
            $conteo = $equipo["conteo"];
            return $conteo;
          }
      }else{
         return 0;
          //echo "No hay equipos disponibles";
      }
}








?>