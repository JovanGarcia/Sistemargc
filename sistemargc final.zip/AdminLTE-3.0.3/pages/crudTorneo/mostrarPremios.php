
<?php
	$selectPremio="SELECT * from tPremio WHERE idTorneo='$idTorneo'";
    $res = $conn->query($selectPremio);
    
echo "
<div class='row mt-3'>
    <div class='col-sm-1'  style='padding: 5px;'>
        <h6><b>Posición #</b></h6>
    </div>
    <div class='col-sm-3'  style='padding: 5px;' >
        <h6><b>Descripción del premio</b></h6>
    </div>
</div>";

	if ($res->num_rows > 0) {
		while($premio=$res->fetch_assoc()){

echo "
<div class='row mt-3'>
    <div class='col-sm-1'  style='padding: 5px;'>
        <h6 id='".$premio["posicion"]."' name='lugar'>".$premio["posicion"]."</h6>
    </div>
    <div class='col-sm-3'  style='padding: 5px;' >
        <h6 id='x' name='x'>".$premio["premio"]."</h6>
    </div>
    <div class='col-sm-2'>
    <a href='deletePremio.php?idPremio=".$premio["idPremio"]."&idTorneo=".$idTorneo."'><button type='button' class='btn btn-danger'><i class='fas fa-times'></i></button></a>
    </div>
</div>";
}
    }else{
        echo "<h6>No hay premios registrados...</h6>";
    }

?>