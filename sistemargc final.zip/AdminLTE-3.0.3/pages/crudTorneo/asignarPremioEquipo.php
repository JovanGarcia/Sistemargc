<?php
#Estableciendo conexión
require_once '../backend/conexion.php';

//Archivo para asignar el premio a uno de los equipos que participan en un Torneo.
$idTorneo = $_GET["idTorneo"];
$idPremio = $_POST["idPremio"];
$idEquipo = $_POST["idEquipo"];

echo "idTorneo = ".$idTorneo."<br>";
echo "idPremio = ".$idPremio."<br>";
echo "idEquipo = ".$idEquipo."<br>";

#Asignamos el idPremio a la tabla tEquipo
$sql = "UPDATE tEquipo SET idPremio='$idPremio'
        WHERE idEquipo='$idEquipo'";

#Indicamos a la tabla tPremio que el premio a sido asignado a un equipo 
$sql2 = "UPDATE tPremio SET asignar='1'
        WHERE idPremio='$idPremio'";


if (mysqli_query($conn, $sql)) {
    if (mysqli_query($conn, $sql2)) {
            echo "<script type='text/javascript'>
            window.location.href='verTorneo.php?idTorneo=".$idTorneo."';
            </script>";
        }else{
            echo "Ha ocurrido un error en actualizar tPremio " . mysqli_error($conn);
        }
   } else {
      echo "Ha ocurrido un error en actualizar tEquipo " . mysqli_error($conn);
   }
//Finalizando conexión   
mysqli_close($conn);


?>