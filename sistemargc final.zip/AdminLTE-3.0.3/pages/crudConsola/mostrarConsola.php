<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$sql="SELECT * from tConsola";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row=$result->fetch_assoc()){
		echo "
		<tr>
			<td>".$row['idConsola']."</td>
			<td>".$row['plataforma']."</td>
			<td>".$row['numero']."</td>
			<td>".$row['serie']."</td>
			<!--<td>".$row['costo']."</td>
			<td>".$row['monedas']."</td>-->
			<td style='text-align: center;'>
				<div class='btn-group'>   
					<a href='../asignarJuego/verConsola.php?idConsola=".$row["idConsola"]."'><button type='button' class='btn btn-success'><i class='fas fa-eye'></i></button></a>                 
                    <a href='FormEditarConsola.php?idConsola=".$row['idConsola']."'><button type='button' class='btn btn-primary'><i class='fas fa-edit'></i></button></a>
                    <a href='EliminarConsola.php?id=".$row['idConsola']."' > <button type='button' class='btn btn-danger'><i class='fas fa-trash-alt'></i></button></a>
                </div>
            </td>
		</tr>
		";
		}
	} else {
	    echo "0 results";
	}

	$conn->close();
?>