<?php
  #Conectando a la base de datos
  require_once '../backend/conexion.php';

  $idConsola = $_POST["idConsola"];
  $plataforma = $_POST["plataforma"];
  $numero = $_POST["numero"];
  $serial = $_POST["serial"];
  $costo = $_POST["costo"];
  $monedas = $_POST["monedas"];

  $sql = "UPDATE tConsola SET plataforma='$plataforma',numero='$numero',serie='$serial',costo='$costo',monedas='$monedas' WHERE idConsola=".$idConsola;


	if (mysqli_query($conn, $sql)) {
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();
  
  header("Location: ListaConsola.php")
  

?>