<?php

	header("Location: ListaConsola.php"); 

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$id = $_GET['id'];

	$sql="DELETE FROM tConsola WHERE idConsola=".$id;

	if (mysqli_query($conn, $sql)) {
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	    $conn->close();

?>

