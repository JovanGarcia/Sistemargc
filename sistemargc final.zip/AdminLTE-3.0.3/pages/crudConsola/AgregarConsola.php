<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	header("Location: ListaConsola.php"); 

	$plataforma = $_POST['plataforma'];
	$numero = $_POST['numero'];
	$serial = $_POST['serial'];
	#$costo = $_POST['costo'];
	#$monedas = $_POST['monedas'];

	$sql = "INSERT INTO tConsola(plataforma, numero, serie)
	    VALUES ('$plataforma','$numero','$serial')";

	if (mysqli_query($conn, $sql)) {
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();


?>