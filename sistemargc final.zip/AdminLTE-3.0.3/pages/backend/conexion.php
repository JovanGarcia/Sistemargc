<?php
$conn = new mysqli('127.0.0.1:3307',  'root', '','sistemargc');
if($conn->connect_errno > 0){
    die('Unable to connect to database [' . $conn->connect_error . ']');
}
mysqli_query($conn,"SET NAMES 'utf8'");
?>

