<?php
//Realizando conexión 
include ('../backend/conexion.php'); 

$idInvitacion = $_GET["idInvitacion"];
$idGamer = $_GET["idGamer"];

echo "idInvitacion es: ".$idInvitacion;
echo "idGamer es: ".$idGamer;

$sql = "UPDATE tInvitacion SET respuesta = '0' WHERE idInvitacion = '$idInvitacion'";

if (mysqli_query($conn, $sql)) {
    echo "<script type='text/javascript'>
    window.location.href='listaInvitaciones.php?idGamer=".$idGamer."';
    </script>";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
    $conn->close();
?>