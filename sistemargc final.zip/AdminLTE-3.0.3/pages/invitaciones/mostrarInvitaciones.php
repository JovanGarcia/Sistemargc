<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

$sql = "SELECT i.idInvitacion 'idInvitacion', e.nombreEquipo 'nombreEquipo', i.idGamer 'idGamer', i.fechaInv 'fechaInv' FROM tEquipo e, tinvitacion i WHERE i.idGamerInv='$idGamer' AND e.idEquipo=i.idEquipo AND i.respuesta IS NULL";
$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($inv=$result->fetch_assoc()){
        
            echo "<tr>
                    <td>".$inv["idInvitacion"]."</td>
                    <td>".$inv["nombreEquipo"]."</td>
                    <td>".$inv["idGamer"]."</td>
                    <td>".$inv["fechaInv"]."</td>
                    <td>TORNEO</td>
                    <td style='text-align: center;'>
                        <div class='btn-group'>
                            <a href='aceptarTorneo.php?idInvitacion=".$inv["idInvitacion"]."&idGamer=".$idGamer."'><button type='button' class='btn btn-success'><i class='fas fa-check-circle'></i>Aceptar</button></a>
                            <a href='rechazarTorneo.php?idInvitacion=".$inv["idInvitacion"]."&idGamer=".$idGamer."'><button type='button' class='btn btn-danger'><i class='fas fa-times-circle'></i>Rechazar</button></a>
                         </div>
                     </td>
                </tr>";
    }
} else {
    //echo "0 Resultados";
}

$conn->close();
?>