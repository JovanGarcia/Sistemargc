<!-- Main Sidebar Container -->
  <aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../index.php" class="brand-link">
      <img src="../../dist/img/AdminLTELogo.png"
           alt="AdminLTE Logo"
           class="brand-image img-circle elevation-3"
           style="opacity: .8">
      <span class="brand-text font-weight-light">GoGamer</span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar">

<!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
          <img src="../imagenes/<?php echo $foto ?>" class="img-circle elevation-2" alt="User Image">
        </div>
        <div class="info">
          <a href="../../index.php" class="d-block"><?php echo $nombreusuario; ?></a>
        </div>
      </div>
<!-- Sidebar Menu -->
<nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

        <li class="nav-header">GAMING</li>

        <li class="nav-item has-treeview menu">
          <a href="#" class="nav-link">
            <i class="fas fa-trophy"></i>
            <p>
              Torneos
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="../gamerTorneo/listaTorneosNormal.php" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Mostrar torneos</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="../invitaciones/listaInvitaciones.php" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Invitaciones</p>
              </a>
            </li>
          </ul>
          
        </li>

        <li class="nav-header">HISTORIAL</li>

        <li class="nav-item has-treeview menu">
            <a href="#" class="nav-link">
              <i class="fas fa-file-alt"></i>
              <p>
                Historiales
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../HistorialRentas/Historial.php" class="nav-link">
                  <i class="fas fa-file-alt"></i>
                  <p>Historial de rentas</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../HistorialMonedas/Historial.php" class="nav-link">
                  <i class="fas fa-file-alt"></i>
                  <p>Historial de monedas</p>
                </a>
              </li>
            </ul>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../HistorialTorneos/listaHistorialTorneos.php" class="nav-link">
                  <i class="fas fa-file-alt"></i>
                  <p>Historial de torneos</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-header">CUENTA</li>

        <li class="nav-item has-treeview menu">
            <a href="#" class="nav-link active">
              <i class="fas fa-user"></i>
              <p>
                Cuenta
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="../logout/logout.php" class="nav-link active">
                  <i class="fas fa-user"></i>
                  <p>Cerrar sesión</p>
                </a>
              </li>
            </ul>
          </li>


      </ul>
    </nav>
    <!-- /.sidebar-menu -->
<!--div>Iconos diseñados por <a href="https://www.flaticon.es/autores/pixelmeetup" title="Pixelmeetup">Pixelmeetup</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/nikita-golubev" title="Nikita Golubev">Nikita Golubev</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/pixel-perfect" title="Pixel perfect">Pixel perfect</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/eucalyp" title="Eucalyp">Eucalyp</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div-->