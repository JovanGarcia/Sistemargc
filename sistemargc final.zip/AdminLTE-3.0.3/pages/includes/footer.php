<footer class="main-footer bg-info">
    <div class="float-right d-none d-sm-block">
      <b>Versión</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2020-2020 <a href="#" style="color: #FFFFFF">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>