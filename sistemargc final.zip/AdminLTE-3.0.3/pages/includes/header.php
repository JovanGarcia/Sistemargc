<?php
require_once '../backend/conexion.php';

  session_start();
  if (isset($_SESSION['usuario'])) {
    $usuario=$_SESSION['usuario'];
    $sql = "SELECT * FROM tGamer WHERE usuario = '".$usuario."'";

    $result = mysqli_query($conn, $sql);
    if (mysqli_num_rows($result) > 0) {
      while($row = mysqli_fetch_assoc($result)) {
        $nombreusuario = $row["nombre"]." ".$row["paterno"]." ".$row["materno"];
        $tipo = $row["tipo"];
        $foto = $row["foto"];
        $idgamer = $row["idGamer"];
      }
    }
  }else{
    header('location: login.php');
  }

?>

<!-- Navbar --><nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Left navbar links -->
    <ul class="navbar-nav">
      <li class="nav-item">
        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
      </li>
    </ul>
    <!-- Right navbar links -->
    <ul class="navbar-nav ml-auto">
      <!-- Messages Dropdown Menu -->
      <li class="nav-item bg-warning">
        <a class="nav-link" href="#">
          <i class="fas fa-coins"></i>
        </a>
      </li>
      <?php
        $sql = "SELECT * FROM tGamer where usuario = '$usuario'";            
        $data = mysqli_query($conn, $sql);
        
        while($row = mysqli_fetch_assoc($data)) {
        ?>
      <li class="nav-item" style="background-color: lightsteelblue;">
        <a class="nav-link" href="#">
            <b style="font-size: 18px;"><?php echo $row['monedas'] ?></b>
        </a>
      </li>
      <?php
        }
?>
      
    </ul>
  </nav>
  <!-- /.navbar -->