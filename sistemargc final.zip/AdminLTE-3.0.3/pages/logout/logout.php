<?php
	session_start();
	$usuario=$_SESSION['usuario'];
	$_SESSION=array();
	session_destroy();
	header('Location: ../../login.php');
?>