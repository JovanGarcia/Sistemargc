<?php
  include_once "../backend/conexion.php";
  if(isset($_GET["mensaje"])){
    $mensaje = "Error: No se tienen suficientes monedas para realizar la venta";
  }else{
    $mensaje = "";
  }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <meta http-equiv="x-ua-compatible" content="ie=edge">

  <title>GamerSystem | Ventas</title>

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">
</head>
<body class="hold-transition sidebar-mini layout-fixed layout-navbar-fixed layout-footer-fixed">
<div class="wrapper">
  <!--Agregando header-->
  <?php include ('../includes/header.php'); ?>

      <?php 
      #Agregando menu
      include "../includes/menuadmin.php" ?>
      
      <!-- /.sidebar-menu -->
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Registro de Venta</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item active">Registro de Venta</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Dulcería</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="agregarVenta.php" method="post"  enctype="multipart/form-data">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-4">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Producto*</label>
                        <select name="producto" class="form-control" required>
                        <?php
                          $sql = "SELECT * FROM tDulce";
                          $res = $conn->query($sql);

                          while($row = $res->fetch_assoc()) {
                        ?>
                          <option name="producto" value="<?php echo $row['nombre']; ?>"><?php echo $row['nombre']." - ".$row['costo']; ?></option>
                        <?php
                          }
                        ?>
                        </select>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Cantidad*</label>
                        <input type="number" class="form-control" placeholder="Cantidad" id="cantidad" name="cantidad" required>
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Usuario*</label>
                        <select name="usuario" class="form-control" required>
                        <?php
                          $sql = "SELECT * FROM tGamer";
                          $res = $conn->query($sql);

                          while($row = $res->fetch_assoc()) {
                        ?>
                          <option value="<?php echo $row['idGamer']; ?>"><?php echo $row['nombre']." ".$row['paterno']." ".$row['materno']." - ".$row['usuario']; ?></option>
                        <?php
                          }
                        ?>
                        </select>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <div class="col-sm-4">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Metodo de pago*</label>
                        <select name="metodo" class="form-control" required>
                          <option value="efectivo">En Efectivo</option>
                          <option value="monedas">En Monedas</option>
                        </select>
                      </div>
                    </div>

                    <div>
                      <h3><?php echo $mensaje; ?></h3>
                    </div>

                  </div>

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Registrar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

  })
</script>
</body>
</html>
