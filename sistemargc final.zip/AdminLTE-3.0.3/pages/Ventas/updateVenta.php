<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos del nuevo gamer
$producto = $_GET['id'];
$nombre = $_POST['nombre'];
$costo = $_POST['costo'];
$costomonedas = $_POST['costomonedas'];
$monedas = $_POST['monedas'];

$sql = "UPDATE tDulce SET nombre = '$nombre', costo = '$costo', costomonedas = '$costomonedas', monedas = '$monedas' WHERE idDulce = '$producto'";

if (mysqli_query($conn, $sql)) {
    #echo "Consulta exitosa";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
$conn->close();

header('Location: Dulceria.php');

?>