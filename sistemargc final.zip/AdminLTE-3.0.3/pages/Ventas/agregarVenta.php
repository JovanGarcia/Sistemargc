<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos de Venta
$producto = $_POST["producto"];
$cantidad = $_POST["cantidad"];
$usuario = $_POST["usuario"];
$metodo = $_POST["metodo"];

$sql = "SELECT * FROM tGamer WHERE idGamer = '$usuario'";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
$monedasgamer = $row["monedas"];

$sql = "SELECT * FROM tDulce WHERE nombre = '$producto'";
$res = $conn->query($sql);
$row = $res->fetch_assoc();
$monedasproducto = $row["monedas"];
$costomonedasproducto = $row["costomonedas"];
$costoproducto = $row["costo"];

$fecha = date("Y")."-".date("m")."-".date("d");

if($metodo == 'monedas'){
	$costototal = $cantidad * $costomonedasproducto;
	$nuevasmonedasgamer = $monedasgamer - $costototal;
	if($nuevasmonedasgamer < 0){
		header('Location: FormVenta.php?mensaje=1');
	}else{
		$sql = "INSERT INTO tVentas(producto, cantidad, precio, fecha, metodo, idGamer) VALUES ('$producto','$cantidad','$costototal','$fecha','En Monedas','$usuario')";

		if (mysqli_query($conn, $sql)) {
		    #echo "Consulta exitosa";
		} else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
		}

		$sql = "UPDATE tGamer SET monedas = '$nuevasmonedasgamer' WHERE idGamer = '$usuario'";

		if (mysqli_query($conn, $sql)) {
			#echo "Consulta exitosa";
		} else {
			echo "Error: " . $sql . "" . mysqli_error($conn);
		}
		header('Location: Ventas.php');
	}
}else{
	$costototal = $cantidad * $costoproducto;
	$monedasganadas = $monedasproducto * $cantidad;
	$nuevasmonedasgamer = $monedasgamer + $monedasganadas;
	$sql = "INSERT INTO tVentas(producto, cantidad, precio, fecha, metodo, idGamer, monedasganadas) VALUES ('$producto','$cantidad','$costototal','$fecha','En Efectivo','$usuario','$monedasganadas')";

	if (mysqli_query($conn, $sql)) {
		#echo "Consulta exitosa";
	} else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}

	$sql = "UPDATE tGamer SET monedas = '$nuevasmonedasgamer' WHERE idGamer = '$usuario'";

	if (mysqli_query($conn, $sql)) {
		#echo "Consulta exitosa";
	} else {
		echo "Error: " . $sql . "" . mysqli_error($conn);
	}

	header('Location: Ventas.php');
}

$conn->close();

?>