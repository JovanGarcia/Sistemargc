<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos de la venta
$venta = $_GET['id'];

$sql = "DELETE FROM tVentas WHERE idVenta = '$venta'";

if (mysqli_query($conn, $sql)) {
    #echo "Consulta exitosa";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
$conn->close();

header('Location: Ventas.php');

?>