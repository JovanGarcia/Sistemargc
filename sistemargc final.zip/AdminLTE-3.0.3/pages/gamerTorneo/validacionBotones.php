<?php
 //Obteniendo la cantidad de integrantes de modalidad.
 $max = obtenerLimite($conn, $idModalidad);
 //Obteniendo la cantidad actual de equipos en un torneo.
 $numEquipos = obtenerNumeroEquipos($conn, $idTorneo);
 //Calculando los espacios ocupados en el torneo(equipos sin importar que aun falten integrantes en un equipo)
 $actual = $max*$numEquipos;
 //Guardando el campo limite de la tabla tEquipo
 $limiteUsuarios = $datos["limite"];

 //Guardando el estatus actual del torneo
 $estatusActual = $datos["estatus"];

 if($actual >= $limiteUsuarios OR $estatusActual == "Finalizado" OR $estatusActual == "Cancelado"){
    echo "<button type='button' class='btn btn-info' data-toggle='modal' data-target='#modal-participar' disabled><i class='fas fa-file-signature mr-1'></i>Participar</button>";
}else{
    echo "<button type='button' class='btn btn-info' data-toggle='modal' data-target='#modal-participar'><i class='fas fa-file-signature mr-1'></i>Participar</button>";
}

if($actual >= $limiteUsuarios OR $idEquipo == 0 OR $conteoEquipo >= $tamMod OR $estatusActual == "Finalizado" OR $estatusActual == "Cancelado"){
    echo "<button type='button' class='btn btn-success' data-toggle='modal' data-target='#modal-invitar' disabled><i class='fas fa-share-alt mr-1'></i>Invitar jugadores</button>";
}else{
    echo "<button type='button' class='btn btn-success' data-toggle='modal' data-target='#modal-invitar'><i class='fas fa-share-alt mr-1'></i>Invitar jugadores</button>";
}



?>

