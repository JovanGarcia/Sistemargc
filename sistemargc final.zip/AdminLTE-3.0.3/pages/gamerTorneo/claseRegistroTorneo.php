<?php

//Consultado la cantidad del grupo modalidad
function obtenerLimite($conn, $idModalidad){

    $sql="SELECT * from tModalidad WHERE idModalidad = '$idModalidad'";
    $result = $conn->query($sql);
  
       if($result->num_rows>0){
         while($dato=$result->fetch_assoc()){
           $grupo = $dato["grupo"];
           return $grupo;
         }
       } else {
          //echo "Ha ocurrido un error en la función obtenerLimite";
          return 0;
       }
}

//Retorna el total de equipos en un torneo
function obtenerNumeroEquipos($conn, $idTorneo){
    $sql="SELECT COUNT(*) 'total' from tEquipo WHERE idTorneo = '$idTorneo'";
    $result = $conn->query($sql);

    if($result->num_rows>0){
        while($dato=$result->fetch_assoc()){
          $total = $dato["total"];
          return $total;
        }
      } else {
         //echo "Ha ocurrido un error en la función obtenerNumeroEquipos";
         return 0;
      }
}

//Contar el número de integrantes de un equipo
function contarMiEquipo($conn, $idEquipo, $idTorneo){
    $sql="SELECT COUNT(*) 'total' FROM tEquipo e, tinvitacion i WHERE e.idTorneo='$idTorneo' AND e.idEquipo=i.idEquipo AND e.idEquipo='$idEquipo'";
    $result = $conn->query($sql);

    if($result->num_rows>0){
        while($dato=$result->fetch_assoc()){
          $total = $dato["total"];
          return $total;
        }
      } else {
         echo "Ha ocurrido un error en la función contarMiEquipo";
         return 0;
      }
}

//Función para mostrar el id del equipo del usuario actual...
function miEquipo($conn, $idGamer, $idTorneo){

  $sql="SELECT e.idEquipo 'idEquipo' FROM tEquipo e, tinvitacion i WHERE e.idTorneo='$idTorneo' AND i.idGamerInv='$idGamer' AND e.idEquipo=i.idEquipo";
  $result = $conn->query($sql);

  if($result->num_rows>0){
      while($dato=$result->fetch_assoc()){
        $id = $dato["idEquipo"];
        return $id;
      }
    } else {
       //echo "No se encontraron filas en la funcion miEquipo";
       return 0;
    }
}

//Obteniendo el tamaño de la modalidad
function tamModalidad($conn, $idModalidad){
  $sql="SELECT * from tModalidad WHERE idModalidad = '$idModalidad'";
  $result = $conn->query($sql);
     if($result->num_rows>0){
       while($dato=$result->fetch_assoc()){
         $grupo = $dato["grupo"];    
         return $grupo;
       }
     } else {
        //echo "Ha ocurrido un error";
        return 0;
     }
}



?>

