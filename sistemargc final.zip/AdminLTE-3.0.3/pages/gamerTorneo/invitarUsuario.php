<?php
//Realizando conexión 
include ('../backend/conexion.php');

$idTorneo = $_GET['idTorneo'];
$idGamerInv = $_POST['idGamerInv'];
$idGamer = $_GET['idGamer'];
$idEquipo = $_GET['idEquipo'];

//Estableciendo fecha de invitacion
date_default_timezone_set("America/Mexico_City");
$fechaInv = date("l d F Y, g i a");

echo "idGamer emisor= ".$idGamer."<br>";
echo "idGamerInv receptor= ".$idGamerInv."<br>";
echo "idEquipo = ".$idEquipo."<br>";
echo "hora = ".$fechaInv."<br>";


//Consulta para registrar datos (excepto idPremio) en la tabla tEquipo
$sql = "INSERT INTO tInvitacion(idGamerInv, idGamer, idEquipo, fechaInv)
VALUES ('$idGamerInv','$idGamer','$idEquipo','$fechaInv')";

//Insertando los datos para la invitacion
if(mysqli_query($conn, $sql)) {
    echo "<script type='text/javascript'>
    window.location.href='verTorneoNormal.php?idGamer=$idGamer&idEquipo=$idEquipo&idTorneo=$idTorneo';
    </script>";
} else {
echo "Error en sql: " . $sql . "" . mysqli_error($conn);
}
$conn->close();


?>