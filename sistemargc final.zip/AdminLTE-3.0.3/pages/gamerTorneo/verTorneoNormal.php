<?php  
//Realizando conexión 
include ('../backend/conexion.php');
//Clase general para torneos
include ('../crudTorneo/claseTorneos.php');
//Clase para realizar funciones en modulo de participar en Torneo
include ('claseRegistroTorneo.php');

$idTorneo = $_GET["idTorneo"];

$sql = "SELECT * FROM tTorneo WHERE idTorneo='$idTorneo'";
$result = mysqli_query($conn, $sql);
$datos = mysqli_fetch_array($result);

//Obteniendo la modalidad
$idModalidad = $datos["idModalidad"];
$modalidad=obtenerModalidad($conn,$idModalidad);

//Obteniendo el id del Usuario
$idGamer = $_GET["idGamer"];

//Obteniendo el idEquipo
$idEquipo = miEquipo($conn, $idGamer, $idTorneo);

//Obtiendo el total de miembros de mi equipo
$conteoEquipo = contarMiEquipo($conn, $idEquipo, $idTorneo);

//Obteniendo el tamaño que abarca la modalidad
$tamMod = tamModalidad($conn, $idModalidad);

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Detalles del Torneo</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- DataTables -->
  <link rel="stylesheet" href="../../plugins/datatables-bs4/css/dataTables.bootstrap4.min.css">
  <link rel="stylesheet" href="../../plugins/datatables-responsive/css/responsive.bootstrap4.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css"> 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">


      <!--Agregando header-->
      <?php include ('../includes/header.php'); ?>

      <?php 
      #Agregando menu
      include "../includes/menu.php" ?>

      
    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">

        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Detalles del torneo</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item"><a href="#">Lista de Torneos</a></li>
              <li class="breadcrumb-item active">Detalles del torneo</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
    <div class="row">
        <div class="col-lg-4 col-6">
            <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">Información adicional</h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <strong><i class="fas fa-book mr-1"></i>Título</strong>

                <p class="text-muted"><?php echo $datos["titulo"] ?></p>

                <hr>

                <strong><i class="fas fa-book mr-1"></i>Descripción</strong>

                <p class="text-muted"><?php echo $datos["descripcion"] ?><p>

                <hr>

                <strong><i class="fas fa-gamepad mr-1"></i>Juego seleccionado</strong>

                <p class="text-muted"><?php echo $datos["juego"] ?></p>

                <hr>

                <strong><i class="far fa-clock mr-1"></i>Fecha y Hora</strong>

                <p class="text-muted"><?php echo $datos["fecha"]."  -  ".$datos["hora"] ?></p>
            </div>
            <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col-->
        <div class="col-lg-4 col-6">
            <div class="card card-info">
            <div class="card-header">
                <h3 class="card-title">Torneo No. <?php echo $datos["idTorneo"] ?></h3>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <strong><i class="fas fa-map-marker-alt mr-1"></i>Forma establecida</strong>

                <p class="text-muted"><?php echo $datos["forma"] ?></p>

                <hr>

                <strong><i class="fas fa-users mr-1"></i>Limite de jugadores</strong>

                <p class="text-muted"><?php echo $datos["limite"] ?><p>

                <hr>

                <strong><i class="fab fa-teamspeak mr-1"></i>Modalidad</strong>


                <p class="text-muted"><?php echo $modalidad ?></p>

                <hr>

                <strong><i class="far fa-file-alt mr-1"></i>Estatus</strong>

                <p class="text-muted"><?php echo $datos["estatus"] ?></p>
            </div>
            <!-- /.card-body -->
            </div>
            <!-- /.card -->
        </div>
        <!-- /.col-->
    </div>
    <!-- /.row-->

    <!--Modal para registrarse en el torneo-->
    <form role="form" action="unirseTorneo.php?idGamer=<?php echo $idGamer."&idTorneo=".$idTorneo ?>" method="post">
            <div class="modal fade" id="modal-participar">
                <div class="modal-dialog">
                  <div class="modal-content bg-info">
                    <div class="modal-header">
                      <h4 class="modal-title">Participar en el Torneo</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <p>Para participar en el Torneo necesita llenar los siguientes datos...</p>
                        <!--Nombre del equipo-->
                        <div class="row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <label>Nombre del equipo*</label>
                                    <input type="text" class="form-control" placeholder="Escribe el nombre de tu equipo..." id="equipo" name="equipo" required>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6" style="text-align: justify;">
                                <h6 class="text-lime">AVISO: Usted está registrandose para participar en el Torneo No. <?php echo $datos["idTorneo"] ?></h6>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer justify-content-between">
                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
                      <button type="submit" class="btn btn-outline-light">Guardar</button>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
    </form>
    <!--/.form-->

        <!--Modal para invitar usuario-->
        <form role="form" action="invitarUsuario.php?idGamer=<?php echo $idGamer."&idEquipo=".$idEquipo."&idTorneo=".$idTorneo ?>" method="post">
            <div class="modal fade" id="modal-invitar">
                <div class="modal-dialog">
                  <div class="modal-content bg-info">
                    <div class="modal-header">
                      <h4 class="modal-title">Participar en el Torneo</h4>
                      <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                        <span aria-hidden="true">&times;</span></button>
                    </div>
                    <div class="modal-body">
                      <p>Seleccione a uno de los siguientes usuarios para enviar una invitacion para el Torneo...</p>
                        <!--Nombre del equipo-->
                        <div class="row">
                            <div class="col-sm-10">
                                <div class="form-group">
                                    <label>Usuarios disponibles*</label>
                                    <select class="form-control" name="idGamerInv" id="idGamerInv" required>
                                        <!--Mostrar los participantes disponibles-->
                                        <?php include ('participantesDisponibles.php'); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6" style="text-align: justify;">
                                <h6 class="text-lime">AVISO: Usted está invitando a un usuario para participar en el Torneo No. <?php echo $datos["idTorneo"] ?></h6>
                            </div>
                        </div>

                    </div>
                    <div class="modal-footer justify-content-between">
                      <button type="button" class="btn btn-outline-light" data-dismiss="modal">Cerrar</button>
                      <button type="submit" class="btn btn-outline-light">Enviar</button>
                    </div>
                  </div>
                  <!-- /.modal-content -->
                </div>
                <!-- /.modal-dialog -->
              </div>
              <!-- /.modal -->
    </form>
    <!--/.form-->

    <!--Fila para visualizar a los jugadores-->
      <div class="row">
        <div class="col-12">
          <div class="card">
            <div class="card-header">
                <div class="row">
                    <div class="col-2">
                         <h3 class="card-title">Participantes del Torneo</h3>
                    </div>
                     <div class="col-10">
                      <div class="btn-group">
                          <?php include ('validacionBotones.php'); ?>
                     </div>
                </div>
            </div>
            <!--/.row-->
            </div>
            <!-- /.card-header -->
            <div class="card-body">
              <table id="example2" class="table table-bordered table-hover">
                <thead>
                <tr>
                  <th>ID</th>
                  <th>Imagen</th>
                  <th>Participante</th>
                  <th>No. Equipo</th>
                  <th>Nombre del equipo</th>
                </tr>
                </thead>
                <tbody>
                      <!--Mostrando los participantes del torneo-->
                     <?php include ('mostrarParticipantes.php'); ?>
                <tbody>
              </table>
            </div>
            <!-- /.card-body -->
          </div>
          <!-- /.card -->
        </div>
        <!-- /.col -->
      </div>
      <!-- /.row -->
    </section>
    <!-- /.content -->
  </div>

  <!--Agregando el footer-->
  <?php include ('../includes/footer.php'); ?>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>
<!-- page script -->
<script>
  $(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>
