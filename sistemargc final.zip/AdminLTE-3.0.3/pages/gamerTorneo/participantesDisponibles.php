<?php
$select="SELECT * from tGamer";
$opc = $conn->query($select);

    if ($opc->num_rows > 0) {
        while($gamer=$opc->fetch_assoc()){
            $idActual = $gamer["idGamer"];
            if($idGamer != $idActual)
            {
                echo "<option value='".$gamer["idGamer"]."'>".$gamer["idGamer"]." : ".$gamer["nombre"]." ".$gamer["paterno"]." ".$gamer["materno"]."</option>";
            }
        }
    }else{
        echo "<option>No hay usuarios disponibles...</option>";
    }
?>
