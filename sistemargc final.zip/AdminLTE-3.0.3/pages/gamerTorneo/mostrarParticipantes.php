<?php
	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$sql="SELECT e.idEquipo 'idEquipo', e.nombreEquipo 'nombreEquipo', i.fechaInv 'fechaInv', g.idGamer 'idGamer', g.nombre 'nombre', g.paterno 'paterno', g.materno 'materno', g.foto 'foto'
        FROM tEquipo e, tInvitacion i, tGamer g WHERE e.idTorneo='$idTorneo' AND e.idEquipo=i.idEquipo AND i.respuesta=1 AND i.idGamerInv=g.idGamer";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($part=$result->fetch_assoc()){
            echo "
            <tr style='text-align:center; '>
                <td>".$part["idGamer"]."</td>
                <td><center><img  width='130' height='130' src='../imagenes/".$part["foto"]."' alt='User Avatar'></center></td>
                <td>".$part["nombre"]." ".$part["paterno"]." ".$part["materno"]."</td>
                <td>".$part["idEquipo"]."</td>
                <td>".$part["nombreEquipo"]."</td>
            </tr>";
            
        }
    } else {
        echo "0 Resultados";
    }

$conn->close();

?>