<?php
//Realizando conexión 
include ('../backend/conexion.php');

$idGamer = $_GET['idGamer'];
$idTorneo = $_GET['idTorneo'];
$equipo = $_POST['equipo'];

//Estableciendo fecha de invitacion
date_default_timezone_set("America/Mexico_City");
$fechaInv = date("l d F Y, g i a");
//Significa que ha aceptado registrarse
$respuesta = 1; 

echo "idGamer y idGamerInv = ".$idGamer."<br>";
echo "idTorneo = ".$idTorneo."<br>";
echo "Nombre del Equipo = ".$equipo."<br>";
echo "respuesta = ".$respuesta."<br>";
echo "hora = ".$fechaInv."<br>";

//Consulta para registrar datos (excepto idPremio) en la tabla tEquipo
$sql = "INSERT INTO tEquipo(idTorneo, nombreEquipo)
VALUES ('$idTorneo','$equipo')";



//Insertando datos en tEquipo y despues obteniendo el ultimo id de esa tabla
//para insertarla en la tabla tInvitacion
if(mysqli_query($conn, $sql)) {
        $idEquipo = mysqli_insert_id($conn);
        //Consulta para registrar los datos de tInvitacion
        $sql2 = "INSERT INTO tInvitacion(idGamerInv, idGamer, idEquipo, fechaInv, respuesta)
        VALUES ('$idGamer','$idGamer','$idEquipo','$fechaInv','$respuesta')";

        if (mysqli_query($conn, $sql2)) {
            echo "<script type='text/javascript'>
            window.location.href='verTorneoNormal.php?idTorneo=$idTorneo&idGamer=$idGamer';
            </script>";
        }else{
            echo "Error: en sql2 " . $sql2 . "" . mysqli_error($conn);
        }
} else {
echo "Error en sql: " . $sql . "" . mysqli_error($conn);
}
$conn->close();


?>