<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	$sql="SELECT * from tPlataformas";
	$result = $conn->query($sql);

	if ($result->num_rows > 0) {
		while($row=$result->fetch_assoc()){
		echo "
		<tr>
			<td>".$row['idPlataforma']."</td>
			<td>".$row['nombre']."</td>
			<td>".$row['costo']."</td>
			<td>".$row['cmonedas']."</td>
			<td>".$row['rmonedas']."</td>
			<td style='text-align: center;'>
                <div class='btn-group'>                    
                    <a href='FormEditarPlataforma.php?idPlataforma=".$row['idPlataforma']."'><button type='button' class='btn btn-primary'><i class='fas fa-edit'></i></button></a>
                    <a href='eliminarPlataforma.php?id=".$row['idPlataforma']."' > <button type='button' class='btn btn-danger'><i class='fas fa-trash-alt'></i></button></a>
                </div>
            </td>
		</tr>
		";
		}
	} else {
	    echo "0 results";
	}

	$conn->close();
?>