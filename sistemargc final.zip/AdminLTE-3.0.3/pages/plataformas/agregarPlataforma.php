<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	

	$nombre = $_POST['nombre'];
	$costo = $_POST['costo'];
	$cMonedas = $_POST['cMonedas'];
	$rMonedas = $_POST['rMonedas'];
	

	$sql = "INSERT INTO tPlataformas(nombre, costo, cmonedas, rmonedas) VALUES ('$nombre','$costo','$cMonedas','$rMonedas')";

	if (mysqli_query($conn, $sql)) {
		header("Location: listaPlataformas.php"); 
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();


?>