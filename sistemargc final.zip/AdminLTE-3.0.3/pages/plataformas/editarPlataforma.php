<?php
  #Conectando a la base de datos
  require_once '../backend/conexion.php';

  $idPlataforma = $_POST["idPlataforma"];
  $nombre = $_POST["nombre"];
  $costo = $_POST["costo"];
  $cmonedas = $_POST["cMonedas"];
  $rmonedas = $_POST["rMonedas"];

  $sql = "UPDATE tplataformas SET nombre='$nombre',costo='$costo',cmonedas='$cmonedas',rmonedas='$rmonedas' WHERE idPlataforma=".$idPlataforma;


	if (mysqli_query($conn, $sql)) {
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();
  
  header("Location: listaPlataformas.php")
  

?>