
<link rel="stylesheet" type="text/css" href="../../font/flaticon.css">  

<!-- Sidebar Menu -->
<nav class="mt-2">
      <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">

        <li class="nav-item">
            <a href="../index.html" class="nav-link">
              <i class="flaticon-mundo"></i>
              <p>
                Inicio
              </p>
            </a>
          </li>

        <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link">
              <i class="flaticon-multijugador"></i>
              <p>
                Gamers
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index2.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Mostrar usuarios</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index3.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Crear usuario</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-header">GAMING</li>

          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link">
              <i class="flaticon-videojuego"></i>
              <p>
                Consolas
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index2.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Mostrar consolas</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index3.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Agregar consola</p>
                </a>
              </li>
            </ul>
          </li>

          <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link">
              <i class="flaticon-discos-compactos"></i>
              <p>
                Juegos
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index2.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Mostrar juegos</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index3.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Agregar juego</p>
                </a>
              </li>
            </ul>
          </li>

        <li class="nav-item has-treeview menu-open">
          <a href="#" class="nav-link">
            <i class="flaticon-lucha"></i>
            <p>
              Torneos
              <i class="right fas fa-angle-left"></i>
            </p>
          </a>
          <ul class="nav nav-treeview">
            <li class="nav-item">
              <a href="./index2.html" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Mostrar torneos</p>
              </a>
            </li>
            <li class="nav-item">
              <a href="./index3.html" class="nav-link">
                <i class="far fa-circle nav-icon"></i>
                <p>Crear torneos</p>
              </a>
            </li>
          </ul>
        </li>

        <li class="nav-header">DULCERÍA</li>

        <li class="nav-item has-treeview menu-open">
            <a href="#" class="nav-link active">
              <i class="flaticon-caja-de-madera"></i>
              <p>
                Miscelánea
                <i class="right fas fa-angle-left"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="./index2.html" class="nav-link active">
                  <i class="flaticon-caramelo"></i>
                  <p>Lista de dulces</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="./index3.html" class="nav-link">
                  <i class="far fa-circle nav-icon"></i>
                  <p>Agregar dulce</p>
                </a>
              </li>
            </ul>
          </li>

      </ul>
    </nav>
    <!-- /.sidebar-menu -->
<!--div>Iconos diseñados por <a href="https://www.flaticon.es/autores/pixelmeetup" title="Pixelmeetup">Pixelmeetup</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/freepik" title="Freepik">Freepik</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/nikita-golubev" title="Nikita Golubev">Nikita Golubev</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/pixel-perfect" title="Pixel perfect">Pixel perfect</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div><div>Iconos diseñados por <a href="https://www.flaticon.es/autores/eucalyp" title="Eucalyp">Eucalyp</a> from <a href="https://www.flaticon.es/"     title="Flaticon">www.flaticon.com</a></div-->