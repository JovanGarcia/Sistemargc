<?php

//Consultado posicion del equipo...
function miPremio($conn, $idPremio){

    if (is_null($idPremio)){
        return "Su equipo no obtuvo ningún premio";
    }
    else{
        $sql = "SELECT posicion, premio  FROM tPremio WHERE idPremio='$idPremio'";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while($datos=$result->fetch_assoc()){
                $lugar = "Posición ".$datos["posicion"]." : ".$datos["premio"];
                return $lugar;
            }
        } else {
            return 0;
        }

    }
}

?>