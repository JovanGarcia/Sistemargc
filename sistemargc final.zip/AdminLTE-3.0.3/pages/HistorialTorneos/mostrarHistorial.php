<?php
#Conectando a la base de datos
include ('../backend/conexion.php');


$sql = "SELECT t.idTorneo 'idTorneo', t.titulo 'titulo', t.juego 'juego',  t.fecha 'fecha', t.hora 'hora', m.tipo 'tipo', e.idEquipo 'idEquipo', e.nombreEquipo 'nombreEquipo', e.idPremio 'idPremio'  FROM tEquipo e, tInvitacion i, tTorneo t, tModalidad m 
        WHERE e.idTorneo=t.idTorneo AND i.idGamerInv='$idGamer' AND i.respuesta=1 AND e.idEquipo=i.idEquipo AND m.idModalidad=t.idModalidad";

$result = $conn->query($sql);

if ($result->num_rows > 0) {
    while($datos=$result->fetch_assoc()){
            $posicion = miPremio($conn, $datos["idPremio"]);
            echo "<tr>
                    <td>".$datos["idTorneo"]."</td>
                    <td>".$datos["titulo"]."</td>
                    <td>".$datos["juego"]."</td>
                    <td>".$datos["tipo"]."</td>
                    <td>No. ".$datos["idEquipo"]." : ".$datos["nombreEquipo"]."</td>
                    <td>".$posicion."</td>
                    <td>".$datos["fecha"]." - ".$datos["hora"]."</td>
                </tr>";
    }
} else {
    //echo "0 Resultados";
}

$conn->close();
?>