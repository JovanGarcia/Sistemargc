<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos del nuevo gamer
$nombre = $_POST['nombre'];
$costo = $_POST['costo'];
$costomonedas = $_POST['costomonedas'];
$monedas = $_POST['monedas'];

$sql = "INSERT INTO tDulce(nombre, costo, costomonedas, monedas) VALUES ('$nombre','$costo','$costomonedas','$monedas')";

if (mysqli_query($conn, $sql)) {
    #echo "Consulta exitosa";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
$conn->close();

header('Location: ../verDulceria/Dulceria.php');

?>