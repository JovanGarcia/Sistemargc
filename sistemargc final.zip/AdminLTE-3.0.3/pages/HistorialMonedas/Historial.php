<?php
  include ('../backend/conexion.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Lista de usuarios</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Agregando navar-->
    <?php include ('../includes/header.php') ?>


      <?php 
      #Agregando menu
      include "../includes/menu.php" ?>

    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Mis monedas</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item active">Historial de monedas</li>
            </ol>
          </div>
        </div>
       
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="card">
          <div class="card-body">
            <table id="example1" class="table table-bordered table-striped">
              <thead>
              <tr class="bg-info">
                <th>ID</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio total</th>
                <th>Fecha</th>
                <th>Metodo de pago</th>
                <th>Monedas Ganadas</th>
              </tr>
              </thead>
              <tbody>
              <?php
              $sql = "SELECT * FROM tVentas WHERE idGamer = '$idgamer' AND metodo = 'En Efectivo'";
              $res = $conn->query($sql);

              while($row = $res->fetch_assoc()) {
              ?>
                  <tr>
                    <td><?php echo $row["idVenta"]; ?></td>
                    <td><?php echo $row["producto"]; ?></td>
                    <td><?php echo $row["cantidad"]; ?></td>
                    <td><?php echo $row["precio"]; ?></td>
                    <td><?php echo $row["fecha"]; ?></td>
                    <td><?php echo $row["metodo"]; ?></td>
                    <td><?php echo $row["monedasganadas"]; ?></td>
                  </tr>
              <?php
              }
              ?>
              </tbody>
              <tfoot>
              <tr class="bg-info">
                <th>ID</th>
                <th>Producto</th>
                <th>Cantidad</th>
                <th>Precio total</th>
                <th>Fecha</th>
                <th>Metodo de pago</th>
                <th>Monedas Ganadas</th>
              </tr>
              </tfoot>
            </table>
          </div>
          <!-- /.card-body -->
        </div>
        <!-- /.card -->
  </section>
  <!-- /.content -->
  </div>

    <!--Agregando el footer-->
    <?php include ('../includes/footer.php'); ?>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>


<!-- DataTables -->
<script src="../../plugins/datatables/jquery.dataTables.js"></script>
<script src="../../plugins/datatables-bs4/js/dataTables.bootstrap4.min.js"></script>
<script src="../../plugins/datatables-responsive/js/dataTables.responsive.min.js"></script>
<script src="../../plugins/datatables-responsive/js/responsive.bootstrap4.min.js"></script>

<script type="text/javascript">
$(function () {
    $("#example1").DataTable({
      "responsive": true,
      "autoWidth": false,
    });
    $('#example2').DataTable({
      "paging": true,
      "lengthChange": false,
      "searching": false,
      "ordering": true,
      "info": true,
      "autoWidth": false,
      "responsive": true,
    });
  });
</script>
</body>
</html>
