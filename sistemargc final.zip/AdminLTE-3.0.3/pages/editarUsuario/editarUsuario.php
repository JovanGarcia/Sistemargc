<?php
    require_once '../backend/conexion.php';

    $idGamer = $_GET["idGamer"];

    $sql = "SELECT * FROM tGamer WHERE idGamer='$idGamer'";
    $result = mysqli_query($conn, $sql);
    $datos = mysqli_fetch_array($result);   
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Modificar usuario</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  

  <!-- SweetAlert2 -->
  <link rel="stylesheet" href="../../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="../../plugins/toastr/toastr.min.css">
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

<!--Agregando el header-->
<?php include ("../includes/header.php") ?>
      
      <?php 
      #Agregando menu
      include ("../includes/menuadmin.php") ?>

    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Modificar usuario</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item"><a href="#">Lista de usuarios</a></li>
              <li class="breadcrumb-item active">Modificar usuario</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Modificar usuario</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="updateUsuario.php?idGamer=<?php echo $idGamer ?>" method="post"  enctype="multipart/form-data">
                <div class="card-body">

                  <div class="row">
                    <div class="col-sm-4">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Nombre*</label>
                        <input type="text" class="form-control" placeholder="Nombre(s)" id="nombre" name="nombre" value="<?php echo $datos["nombre"] ?>">
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Apellido paterno*</label>
                        <input type="text" class="form-control" placeholder="Apellido paterno" id="paterno" name="paterno" value="<?php echo $datos["paterno"] ?>">
                      </div>
                    </div>
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Apellido materno*</label>
                        <input type="text" class="form-control" placeholder="Apellido materno" id="materno" name="materno" value="<?php echo $datos["materno"] ?>">
                      </div>
                    </div>
                  </div>

                  <!--Fecha de nacimiento-->
                  <div class="row">
                    <div class="col-sm-4">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Fecha de nacimiento*</label>
                        <input type="date" class="form-control" id="fecha" name="fecha" value="<?php echo $datos["fechaNac"] ?>">
                      </div>
                    </div>

                    <!--Genero-->
                    <div class="col-sm-2">
                      <div class="form-group">
                        <label>Genero*</label>
                        <select class="form-control" name="genero">
                            <?php if( $datos["genero"] == "Hombre")
                            {
                                echo "<option value='Hombre'>Hombre</option>";
                                echo "<option value='Mujer'>Mujer</option>";
                            }else{
                                echo "<option value='Mujer'>Mujer</option>";
                                echo "<option value='Hombre'>Hombre</option>";
                            }
                            
                            ?>
                          
                        </select>
                      </div>
                    </div>

                    <!--Telefono-->
                    <div class="col-sm-6">
                      <div class="form-group">
                        <label>Celular*</label>
      
                        <div class="input-group">
                          <div class="input-group-prepend">
                            <span class="input-group-text"><i class="fas fa-phone"></i></span>
                          </div>
                          <input type="text" class="form-control" data-inputmask='"mask": "(999) 999-9999"' data-mask name="celular" id="celular" value="<?php echo $datos["celular"] ?>">
                        </div>
                        <!-- /.input group -->
                      </div>
                  </div>
                </div>

                <div class="row">
                  <!--Correo-->
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label>Correo electrónico*</label>
                      <input type="email" placeholder="Correo electrónico" class="form-control" id="correo" name="correo" value="<?php echo $datos["correo"] ?>">
                    </div>
                  </div>

                  <!--Genero-->
                  <div class="col-sm-6">
                    <div class="form-group">
                      <label>Usuario*</label>
                      <input type="text" placeholder="Usuario" class="form-control" id="usuario" name="usuario" value="<?php echo $datos["usuario"] ?>">
                    </div>
                  </div>
              </div><!-- .row -->

              
              <div class="row">
                <!--Correo-->
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Contraseña*</label>
                    <input type="password" placeholder="Contraseña" class="form-control" id="password1" name="password1" value="<?php echo $datos["contrasena"] ?>">
                  </div>
                </div>

                <!--Genero-->
                <div class="col-sm-6">
                  <div class="form-group">
                    <label>Confirmar contraseña*</label>
                    <input type="password" placeholder="Confirmar contraseña" class="form-control" id="password2" name="password2" value="<?php echo $datos["contrasena"] ?>">
                  </div>
                </div>
            </div><!-- .row -->


              <div class="row">                
                <div class="col-sm-8">
                  <div class="form-group">
                    <label for="exampleInputFile">Cargar imagen de perfil</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input type="file" class="custom-file-input" name="file" id="file">
                        <label class="custom-file-label" for="exampleInputFile">Seleccionar archivo</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Foto</span>
                      </div>
                    </div>
                  </div>
                </div>

              <div class="col-sm-4">
                <div class="form-group">
                  <label>Tipo de usuario*</label>
                  <select class="form-control" name="tipo">
                      <?php if($datos["tipo"] == "Administrador"){
                          echo "<option value='Administrador'>Administrador</option>";
                          echo "<option value='Normal'>Normal</option>";
                      } else{
                        echo "<option value='Normal'>Normal</option>";
                        echo "<option value='Administrador'>Administrador</option>";
                      }?>
                  </select>
                </div>
              </div>

            </div><!-- .row -->


            <div class="row">        
              
              <div class="col-sm-6">
                <div class="form-group">
                  <label>Twitter</label>
                  <input type="text" placeholder="Usuario de Twitter" class="form-control" id="twitter" name="twitter" value="<?php echo $datos["twitter"] ?>">
                </div>
              </div>

            </div><!-- .row-->

            <div class="row"> 

              <div class="col-sm-6">
                <div class="form-group">
                  <label>Facebook</label>
                  <input type="text" placeholder="Usuario de Facebook" class="form-control" id="facebook" name="facebook" value="<?php echo $datos["facebook"] ?>">
                </div>
              </div>

            </div><!-- .row-->

            <div class="row"> 

              <div class="col-sm-6">
                <div class="form-group">
                  <label>Twitch</label>
                  <input type="text" placeholder="Usuario de Twitch" class="form-control" id="twitch" name="twitch" value="<?php echo $datos["twitch"] ?>">
                </div>
              </div>

            </div><!-- .row-->

            <div class="row"> 
              
              <div class="col-sm-6">
                <div class="form-group">
                  <label>Mixer</label>
                  <input type="text" placeholder="Usuario de Mixer" class="form-control" id="mixer" name="mixer" value="<?php echo $datos["mixer"] ?>">
                </div>
              </div>

            </div><!-- .row-->
            
            <div class="row"> 

              <div class="col-sm-6">
                <div class="form-group">
                  <label>Youtube</label>
                  <input type="text" placeholder="Usuario de Youtube" class="form-control" id="youtube" name="youtube" value="<?php echo $datos["youtube"] ?>">
                </div>
              </div>

            </div><!-- .row-->
            
            <div class="row"> 

              <div class="col-sm-6">
                <div class="form-group">
                  <label>Discord</label>
                  <input type="text" placeholder="Usuario de Discord" class="form-control" id="discord" name="discord" value="<?php echo $datos["discord"] ?>">
                </div>
              </div>

            </div><!-- .row-->

            

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary" name="registrar" id="registrar">Registrar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>

         <!--Agregando el footer-->
         <?php include ('../includes/footer.php'); ?>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<!-- SweetAlert2 -->
<script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="../../plugins/toastr/toastr.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });

    $('.swalDefaultSuccess').click(function() {
      Toast.fire({
        type: 'success',
        title: 'Lorem ipsum dolor sit amet, consetetur sadipscing elitr.'
      })
    });

  })
</script>
</body>
</html>
