
<?php
#Estableciendo conexión
require_once '../backend/conexion.php';

#Obteniendo los datos del gamer
$idGamer = $_GET['idGamer'];
$nombre = $_POST['nombre'];
$paterno = $_POST['paterno'];
$materno = $_POST['materno'];
$fecha = $_POST['fecha'];
$genero = $_POST['genero'];
$celular = $_POST['celular'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$tipo = $_POST['tipo'];
$twitter = $_POST['twitter'];
$twitch = $_POST['twitch'];
$facebook = $_POST['facebook'];
$mixer = $_POST['mixer'];
$youtube = $_POST['youtube'];
$discord = $_POST['discord'];

#Consulta para modificar campos de la tabla tGamer
$sql = "UPDATE tGamer SET nombre = '$nombre', paterno = '$paterno', materno = '$materno', fechaNac = '$fecha', genero = '$genero', celular = '$celular', correo = '$correo', usuario = '$usuario', contrasena = '$password1', tipo = '$tipo', twitter = '$twitter', twitch = '$twitch', facebook = '$facebook', mixer = '$mixer', youtube = '$youtube', discord = '$discord'   
        WHERE idGamer='$idGamer'";


      
        if ($password1 == $password2)
        {
            if (mysqli_query($conn, $sql)) {
              
                /*echo "<script type='text/javascript'>
                        window.location.href='../ListaUsuarios/listaUsuarios.php';
                      </script>";*/
                #echo "Actualización exitosa";
            } else {
                echo "Error al actualizar: " . mysqli_error($conn);
            }
            
        }else{
            echo "Las constraseñas no son iguales";
        }

?>

<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>RGC | General Form Elements</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!-- SweetAlert2 -->
    <link rel="stylesheet" href="../../plugins/sweetalert2-theme-bootstrap-4/bootstrap-4.min.css">
  <!-- Toastr -->
  <link rel="stylesheet" href="../../plugins/toastr/toastr.min.css">

    <!--Flaticon-->
    <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  
  
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
 

<!--Agregando header-->
<?php include "../includes/header.php" ?>
      
      <?php include ("../includes/menuadmin.php") ?>

    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">

      
            
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->


  <!--Agregando footer-->
  <?php  include ("../includes/footer.php")  ?>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<!-- SweetAlert2 -->
<script src="../../plugins/sweetalert2/sweetalert2.min.js"></script>
<!-- Toastr -->
<script src="../../plugins/toastr/toastr.min.js"></script>

<script type="text/javascript">
//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

    const Toast = Swal.mixin({
      toast: true,
      position: 'top-end',
      showConfirmButton: false,
      timer: 3000
    });

    //Funcion para mostrar mensaje de exito
    $('.swalDefaultSuccess').ready(function() {
      Toast.fire({
        type: 'success',
        title: 'El usuario ha sido actualizado correctamente.',
    
      })
    });


  })

  //Direccionar a otra página
  function Navegar() {
    window.location.href="../ListaUsuarios/listaUsuarios.php";
}

setTimeout(Navegar, 2000);

</script>
</body>
</html>
