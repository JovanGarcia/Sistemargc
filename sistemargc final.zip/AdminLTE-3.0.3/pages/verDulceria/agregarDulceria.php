<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos del nuevo gamer
$nombre = $_POST['nombre'];
$paterno = $_POST['paterno'];
$materno = $_POST['materno'];
$fecha = $_POST['fecha'];
$genero = $_POST['genero'];
$celular = $_POST['celular'];
$correo = $_POST['correo'];
$usuario = $_POST['usuario'];
$password1 = $_POST['password1'];
$password2 = $_POST['password2'];
$tipo = $_POST['tipo'];
$twitter = $_POST['twitter'];
$twitch = $_POST['twitch'];
$facebook = $_POST['facebook'];
$mixer = $_POST['mixer'];
$youtube = $_POST['youtube'];
$discord = $_POST['discord'];

#Variables para guardar la imagen
$directorio = "../imagenes/";
$archivo = $directorio . basename($_FILES["file"]["name"]);
$tipoArchivo = strtolower(pathinfo($archivo,PATHINFO_EXTENSION));
$checarSiImagen = getimagesize($_FILES["file"]["tmp_name"]);
$foto = basename($_FILES["file"]["name"]);
echo "archivo: ".$foto;


if($password1 == $password2)
{
    if($checarSiImagen != false){
        $size = $_FILES["file"]["size"];
        if($size > 500000){
            echo "El archivo tiene que ser menor a 500kb";
        }else{
            if($tipoArchivo == "jpg" || $tipoArchivo == "jpeg" || $tipoArchivo == "png"){
                if(move_uploaded_file($_FILES["file"]["tmp_name"], $archivo)){
                    echo "La imagen ha sido subida correctamente";
    
                }else{
                    echo "Hubo un error al subir la imagen";
                }
    
            }else{
                echo "Solo se admiten archivos jpg/jpeg/png";
            }
    
        }
    }
    else{
        echo "El documento no es una imagen";
    }

    $sql = "INSERT INTO tGamer(nombre, paterno, materno, fechaNac, genero, celular, correo, usuario, contrasena, foto, tipo, monedas, twitter, twitch, facebook, mixer, youtube, discord)
    VALUES ('$nombre','$paterno','$materno','$fecha','$genero','$celular','$correo','$usuario','$password1','$foto','$tipo','0','$twitter','$twitch','$facebook','$mixer','$youtube','$discord')";

    if (mysqli_query($conn, $sql)) {
        #echo "Consulta exitosa";
    } else {
    echo "Error: " . $sql . "" . mysqli_error($conn);
    }
        $conn->close();
}
else
{
    echo'<script type="text/javascript">
	    		alert("Constraseña incorrecta");
	    		</script>';
}


?>