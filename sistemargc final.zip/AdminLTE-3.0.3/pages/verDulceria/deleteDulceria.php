<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos del nuevo gamer
$producto = $_GET['id'];

$sql = "DELETE FROM tDulce WHERE idDulce = '$producto'";

if (mysqli_query($conn, $sql)) {
    #echo "Consulta exitosa";
} else {
echo "Error: " . $sql . "" . mysqli_error($conn);
}
$conn->close();

header('Location: Dulceria.php');

?>