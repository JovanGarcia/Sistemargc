<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

$sql = "SELECT idGamer, usuario, nombre, paterno, materno, tipo FROM tGamer";
$res = $conn->query($sql);


if ($res->num_rows > 0) {
    while($row = $res->fetch_assoc()) {
        echo "
        <tr>
            <td>".$row["idGamer"]."</td>
            <td>".$row["usuario"]."</td>
            <td>".$row["nombre"]." ".$row["paterno"]." ".$row["materno"]."</td>
            <td>".$row["tipo"]."</td>
            <td style='text-align: center;'>
                <div class='btn-group'>
                <a href='../editarUsuario/editarUsuario.php?idGamer=".$row["idGamer"]."'><button type='button' class='btn btn-primary'><i class='fas fa-edit'></i></button></a>
                <a href='../verUsuario/verUsuario.php?idGamer=".$row["idGamer"]."'><button type='button' class='btn btn-danger'><i class='fas fa-trash-alt'></i></button></a>
                </div>
            </td>
        </tr>";
    }

} else {
    echo "0 results";
}

$conn->close();

?>