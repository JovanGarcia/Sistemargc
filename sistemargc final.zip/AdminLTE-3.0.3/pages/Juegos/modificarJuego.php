<?php
#Conectando a la base de datos
include ('../backend/conexion.php');

#Obteniendo los datos del gamer
$id = $_GET["id"];
$titulo = $_POST['nombre'];
$plataforma = $_POST['plataforma'];

#Variables para guardar la imagen
$directorio = "../imagenes/";
$archivo = $directorio . basename($_FILES["file"]["name"]);
$tipoArchivo = strtolower(pathinfo($archivo,PATHINFO_EXTENSION));
$checarSiImagen = getimagesize($_FILES["file"]["tmp_name"]);
$foto = basename($_FILES["file"]["name"]);
echo "archivo: ".$foto;

    if($checarSiImagen != false){
        $size = $_FILES["file"]["size"];
        if($size > 500000){
            echo "El archivo tiene que ser menor a 500kb";
        }else{
            if($tipoArchivo == "jpg" || $tipoArchivo == "jpeg" || $tipoArchivo == "png"){
                if(move_uploaded_file($_FILES["file"]["tmp_name"], $archivo)){
                    echo "La imagen ha sido subida correctamente";
    
                }else{
                    echo "Hubo un error al subir la imagen";
                }
    
            }else{
                echo "Solo se admiten archivos jpg/jpeg/png";
            }
    
        }
    }
    else{
        echo "El documento no es una imagen";
    }
    if(count($plataforma)==1){
        $sql = "UPDATE tJuego SET imagen= '$foto', titulo = '$titulo', plataforma = '$plataforma[0]' WHERE idJuego = '$id'";
    }
    if(count($plataforma)==2){
        $sql = "UPDATE tJuego SET imagen= '$foto', titulo = '$titulo', plataforma = '$plataforma[0], $plataforma[1]' WHERE idJuego = '$id'";
    }
    if(count($plataforma)==3){
        $sql = "UPDATE tJuego SET imagen= '$foto', titulo = '$titulo', plataforma = '$plataforma[0], $plataforma[1], $plataforma[2]' WHERE idJuego = '$id'";
    }
    

    if (mysqli_query($conn, $sql)) {
        #echo "Juego actualizado";
        header("location: Juegos.php");
    } else {
    echo "Error: " . $sql . "" . mysqli_error($conn);
    }
        $conn->close();



?>