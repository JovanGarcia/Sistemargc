<?php 
	 include_once '../backend/conexion.php';    
   $id = $_GET["id"];
  

   $sql = "DELETE FROM tJuego WHERE idJuego = '$id'";

   if (mysqli_query($conn, $sql)) {
   	echo "<b>Se han eliminado registros</b>";
    //header("Location: paciente.php?user=$user");
    header("Location: Juegos.php");
   }else{
   	  echo "Algo esta mal. ";
   }
   ?>