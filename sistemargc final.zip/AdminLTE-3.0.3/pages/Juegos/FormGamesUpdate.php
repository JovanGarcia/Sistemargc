<?php
  include ('../backend/conexion.php');
?>
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer | Modificar juego</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

  <!--Flaticon-->
  <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css">  

</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
 
    <!--Agregando header-->
    <?php include ('../includes/header.php'); ?>

      <?php 
      #Agregando menu
      include "../includes/menuadmin.php" ?>

    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Registro de Juego Nuevo</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Inicio</a></li>
              <li class="breadcrumb-item"><a href="#">Lista de juegos</a></li>
              <li class="breadcrumb-item active">Modificar juego</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Juego Nuevo</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <?php 
                    include ('../backend/conexion.php');
                    $id = $_GET["id"];
                    $sentencia = "SELECT * FROM tJuego WHERE idJuego = '$id'";
                    foreach ($conn->query($sentencia) as $row ) { 
                        #$img=$row['imagen'].".jpg";                      
                ?>
              <form role="form" action="modificarJuego.php?id=<?php echo $id?>" method="post"  enctype="multipart/form-data">
                <div class="card-body">
                
                  <div class="row">
                    <div class="col-sm-4">
                      <!-- text input -->
                      <div class="form-group">
                        <label>Titulo*</label>
                        <input type="text" value="<?php echo $row['titulo']; ?>" class="form-control" placeholder="Nombre(s)" id="nombre" name="nombre" required>
                      </div>
                    </div>
                    <!--nuevo plataforma-->
                    <div class="col-sm-2">
                      <div class="form-group">
                        <label>Plataforma*</label>
                        <select for="plataforma" name="plataforma[]" class="selectpicker" multiple>
                          <option value="Xbox One">Xbox One</option>
                          <option value="Playstation 4">PlayStation 4</option>
                          <option value="Nintendo Switch">Nintendo Switch</option>
                        </select>
                      </div>
                    </div>
                  </div>



              <div class="row">                
                <div class="col-sm-8">
                  <div class="form-group">
                    <label for="exampleInputFile">Cargar imagen de juego</label>
                    <div class="input-group">
                      <div class="custom-file">
                        <input value="<?php echo $row['imagen']; ?>" type="file" class="custom-file-input" name="file" id="file">
                        <label value="<?php echo $row['imagen']; ?>" class="custom-file-label" for="exampleInputFile">Seleccionar archivo</label>
                      </div>
                      <div class="input-group-append">
                        <span class="input-group-text" id="">Foto</span>
                      </div>
                    </div>
                  </div>
                </div>
                <?php }  ?>
            

                </div>
                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 1.0.0
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- Latest compiled and minified CSS -->
<link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/css/bootstrap-select.min.css">

<!-- Latest compiled and minified JavaScript -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/bootstrap-select.min.js"></script>

<!-- (Optional) Latest compiled and minified JavaScript translation files -->
<script src="https://cdn.jsdelivr.net/npm/bootstrap-select@1.13.9/dist/js/i18n/defaults-*.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

  })
</script>
</body>
</html>
