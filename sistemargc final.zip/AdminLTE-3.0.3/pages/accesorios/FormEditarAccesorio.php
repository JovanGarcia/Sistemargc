<?php
  #Conectando a la base de datos
  require_once '../backend/conexion.php';

  $idAccesorio = $_GET["idAccesorio"];

  $sql = "SELECT * FROM tAccesorios WHERE idAccesorios=".$idAccesorio;
  $result = mysqli_query($conn, $sql);
  $datos = mysqli_fetch_array($result);

  $nombre = $datos["nombre"];
  $costo = $datos["costo"];
  $cmonedas = $datos["monedas"];
  #$rmonedas = $datos["rmonedas"];

?>
<?php 
  #Conectando a la base de datos
  include ('../backend/conexion.php');
 ?>


<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>GoGamer  | Lista de accesorios</title>
  <!-- Tell the browser to be responsive to screen width -->
  <meta name="viewport" content="width=device-width, initial-scale=1">

  <!-- Font Awesome -->
  <link rel="stylesheet" href="../../plugins/fontawesome-free/css/all.min.css">
  <!-- Ionicons -->
  <link rel="stylesheet" href="https://code.ionicframework.com/ionicons/2.0.1/css/ionicons.min.css">
  <!-- Theme style -->
  <link rel="stylesheet" href="../../dist/css/adminlte.min.css">
  <!-- Google Font: Source Sans Pro -->
  <link href="https://fonts.googleapis.com/css?family=Source+Sans+Pro:300,400,400i,700" rel="stylesheet">

    <!--Flaticon-->
    <link rel="stylesheet" type="text/css" href="../../icon/font/flaticon.css"> 
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!--Agregando el header-->
    <?php include ('../includes/header.php'); ?>


      <!--Agregando menu -->
      <?php include ('../includes/menuAdmin.php') ?>


    </div>
    <!-- /.sidebar -->
  </aside>

  <!-- Content Wrapper. Contains page content -->
  <div class="content-wrapper">
    <!-- Content Header (Page header) -->
    <section class="content-header">
      <div class="container-fluid">
        <div class="row mb-2">
          <div class="col-sm-6">
            <h1>Editar accesorio</h1>
          </div>
          <div class="col-sm-6">
            <ol class="breadcrumb float-sm-right">
              <li class="breadcrumb-item"><a href="#">Home</a></li>
              <li class="breadcrumb-item active">Editar accesorio</li>
            </ol>
          </div>
        </div>
      </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
      <div class="container-fluid">
            <!-- general form elements -->
            <div class="card card-primary">
              <div class="card-header">
                <h3 class="card-title">Editar accesorio</h3>
              </div>
              <!-- /.card-header -->
              <!-- form start -->
              <form role="form" action="editarAccesorio.php" method="post"  enctype="multipart/form-data">
                <div class="card-body">

                  <!--Plataforma a elegir-->
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Accesorio*</label>
                        <input type="text" class="form-control" name="nombre" id="nombre" required="required" value=<?php echo $nombre; ?>>
                      </div>
                    </div>
                  </div>

                  <div class="row">
                    <h3>Costos</h3>
                  </div>

                  <!--Numero de consola-->
                  <div class="row">
                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Costo*</label>
                        <input type="number" class="form-control" name="costo" id="costo" required="required" value=<?php echo $costo; ?>>
                      </div>
                    </div>

                    <div class="col-sm-4">
                      <div class="form-group">
                        <label>Costo en monedas*</label>
                        <input type="number" class="form-control" name="monedas" id="monedas" required="required" value=<?php echo $cmonedas; ?>>
                      </div>
                    </div>
                  </div>

                  <!--<div><h3>Recompensa</h3></div>-->

                <div class="row">
                  <!--Costo de la consola-->
                  <div class="col-sm-4">
                      <!-- number input -->
                      <div class="form-group">
                        <!--<label>Monedas se regalo*</label>
                        <input type="number" class="form-control" id="rMonedas" name="rMonedas" min="0" required="required" value=<?php #echo $rmonedas; ?>>
                      --></div>
                    </div>
                </div>


                <div class="row">
                  <div class="col-sm-4" style="display: none" >
                      <input type="number" class="form-control" id="idAccesorio" name="idAccesorio" value=<?php echo $idAccesorio ?>>
                  </div>
                </div>

                <!-- /.card-body -->

                <div class="card-footer">
                  <button type="submit" class="btn btn-primary">Actualizar</button>
                </div>
              </form>
            </div>
            <!-- /.card -->
      </div><!-- /.container-fluid -->
    </section>
    <!-- /.content -->
  </div>
  <!-- /.content-wrapper -->
  <footer class="main-footer">
    <div class="float-right d-none d-sm-block">
      <b>Version</b> 3.0.3
    </div>
    <strong>Copyright &copy; 2014-2019 <a href="http://adminlte.io">AdminLTE.io</a>.</strong> All rights
    reserved.
  </footer>

  <!-- Control Sidebar -->
  <aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
  </aside>
  <!-- /.control-sidebar -->
</div>
<!-- ./wrapper -->

<!-- jQuery -->
<script src="../../plugins/jquery/jquery.min.js"></script>
<!-- Bootstrap 4 -->
<script src="../../plugins/bootstrap/js/bootstrap.bundle.min.js"></script>
<!-- bs-custom-file-input -->
<script src="../../plugins/bs-custom-file-input/bs-custom-file-input.min.js"></script>
<!-- AdminLTE App -->
<script src="../../dist/js/adminlte.min.js"></script>
<!-- AdminLTE for demo purposes -->
<script src="../../dist/js/demo.js"></script>

<script src="../../plugins/select2/js/select2.full.min.js"></script>
<!-- Bootstrap4 Duallistbox -->
<script src="../../plugins/bootstrap4-duallistbox/jquery.bootstrap-duallistbox.min.js"></script>
<!-- InputMask -->
<script src="../../plugins/moment/moment.min.js"></script>
<script src="../../plugins/inputmask/min/jquery.inputmask.bundle.min.js"></script>

<script type="text/javascript">
$(document).ready(function () {
  bsCustomFileInput.init();
});


//Page Form Advanced
$(function () {
    //Money Euro
    $('[data-mask]').inputmask()

  })
</script>
</body>
</html>
