<?php
  #Conectando a la base de datos
  require_once '../backend/conexion.php';

  $idAccesorio = $_POST["idAccesorio"];
  $nombre = $_POST["nombre"];
  $costo = $_POST["costo"];
  $cmonedas = $_POST["monedas"];
  #$rmonedas = $_POST["rMonedas"];

  $sql = "UPDATE tAccesorios SET nombre='$nombre',costo='$costo',monedas='$cmonedas' WHERE idAccesorios=".$idAccesorio;


	if (mysqli_query($conn, $sql)) {
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();
  
  header("Location: listaAccesorios.php")
  

?>