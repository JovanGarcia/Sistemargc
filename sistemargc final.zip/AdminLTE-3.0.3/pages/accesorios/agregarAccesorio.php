<?php

	#Conectando a la base de datos
	include ('../backend/conexion.php');

	

	$nombre = $_POST['nombre'];
	$costo = $_POST['costo'];
	$cMonedas = $_POST['cMonedas'];
	#$rMonedas = $_POST['rMonedas'];
	

	$sql = "INSERT INTO tAccesorios(nombre, costo, monedas) VALUES ('$nombre','$costo','$cMonedas')";

	if (mysqli_query($conn, $sql)) {
		header("Location: listaAccesorios.php"); 
	    #echo "Consulta exitosa";
	} else {
	    echo "Error: " . $sql . "" . mysqli_error($conn);
	}
	$conn->close();


?>